# -*- coding: utf-8 -*-
"""
📚 دليل التطبيق العملي للتحسينات الـ 20
شرح خطوة بخطوة كيفية دمج التحسينات في final_bot_with_image.py
"""

# ═══════════════════════════════════════════════════════════════════════════════
# مثال 1: استخدام نظام Logging
# ═══════════════════════════════════════════════════════════════════════════════

"""
📌 الموضع في final_bot_with_image.py: في أعلى الملف بعد الاستيرادات

البدل الحالي:
    print("خطأ:", error)

بالتحسين الجديد:
"""

from improvements import DatabaseLogger

# تهيئة الـ Logger
db_logger = DatabaseLogger(log_file="bot_logs.log")

# في أي دالة:
@bot.message_handler(commands=['start'])
def handle_start(message):
    db_logger.info(f"بدء جديد من المستخدم", extra_data={'user_id': message.from_user.id})
    # الرسالة سيتم حفظها في bot_logs.log مع timestamp و function name


# ═══════════════════════════════════════════════════════════════════════════════
# مثال 2: معالجة الأخطاء الموحدة
# ═══════════════════════════════════════════════════════════════════════════════

"""
البدل الحالي:
    try:
        data = get_student_data(student_id)
    except Exception as e:
        print(f"Error: {e}")
        bot.send_message(user_id, "حدث خطأ")

بالتحسين الجديد:
"""

from improvements import ErrorHandler

error_handler = ErrorHandler(bot, ADMIN_IDS, db_logger)

# في أي دالة:
try:
    data = supabase.table('students').select('*').eq('id', student_id).execute()
except Exception as e:
    # خطأ عام (يرسل رسالة للمستخدم فقط)
    error_handler.handle(
        f"فشل جلب بيانات الطالب {student_id}",
        exception=e,
        user_id=user_id,
        critical=False
    )
    bot.send_message(user_id, "⚠️ حدث خطأ، يرجى المحاولة لاحقاً")

# خطأ حرج (يرسل تنبيه للمسؤول)
try:
    backup_data()
except Exception as e:
    error_handler.handle(
        "فشل النسخ الاحتياطي!",
        exception=e,
        critical=True  # ← سيرسل للمسؤول
    )


# ═══════════════════════════════════════════════════════════════════════════════
# مثال 3: إعادة المحاولة مع Backoff
# ═══════════════════════════════════════════════════════════════════════════════

"""
البدل الحالي:
    data = supabase.table('students').select('*').execute()
    # قد يفشل عند الضغط العالي

بالتحسين الجديد:
"""

from improvements import retry_with_backoff

@retry_with_backoff(max_retries=3, initial_delay=1)
def fetch_student_safe(student_id):
    return supabase.table('students').select('*').eq('id', student_id).execute()

# الاستخدام:
try:
    data = fetch_student_safe(student_id)
except Exception as e:
    error_handler.handle("فشل جلب البيانات بعد 3 محاولات", exception=e, user_id=user_id)


# ═══════════════════════════════════════════════════════════════════════════════
# مثال 4: تقسيم الرسائل الطويلة
# ═══════════════════════════════════════════════════════════════════════════════

"""
البدل الحالي:
    bot.send_message(user_id, long_report)  # قد يتجاوز 4096 حرف!

بالتحسين الجديد:
"""

from improvements import MessageSplitter

# تقرير طويل جداً (مثلاً 10000 حرف)
full_report = generate_detailed_report(student_id)

# إرسال آمن تلقائياً:
MessageSplitter.send_long_message(bot, user_id, full_report, reply_markup=buttons)

# أو الحصول على رسائل منفصلة:
messages = MessageSplitter.split_message(full_report, max_lines=50)
for msg in messages:
    bot.send_message(user_id, msg)


# ═══════════════════════════════════════════════════════════════════════════════
# مثال 5: التحقق من البيانات المدخلة
# ═══════════════════════════════════════════════════════════════════════════════

"""
البدل الحالي:
    name = message.text
    data = supabase.table('students').select('*').ilike('name', f'%{name}%').execute()
    # خطر: قد يكون هناك SQL Injection!

بالتحسين الجديد:
"""

from improvements import InputValidator

@bot.message_handler(commands=['search'])
def handle_search(message):
    name = message.text.replace('/search', '').strip()
    
    # التحقق
    is_valid, result = InputValidator.validate_student_name(name)
    
    if not is_valid:
        bot.send_message(message.from_user.id, result)  # رسالة الخطأ
        return
    
    # البحث الآمن
    safe_name = InputValidator.sanitize_sql_input(result)
    data = supabase.table('students').select('*').ilike('name', f'%{safe_name}%').execute()
    
    if not data.data:
        bot.send_message(message.from_user.id, "❌ لم يتم العثور على طالب")
    else:
        for student in data.data:
            bot.send_message(message.from_user.id, format_student(student))


# ═══════════════════════════════════════════════════════════════════════════════
# مثال 6: نظام Caching المتقدم
# ═══════════════════════════════════════════════════════════════════════════════

"""
البدل الحالي:
    def get_student_data(student_id):
        return supabase.table('students').select('*').eq('id', student_id).execute()
    
    # كل استدعاء يجلب من قاعدة البيانات!

بالتحسين الجديد:
"""

from improvements import AdvancedCache

# تهيئة الـ Cache (صلاحية عضو Ø بـ 30 دقيقة)
student_cache = AdvancedCache(default_ttl_seconds=1800)

def get_student_data_cached(student_id):
    # البحث في الـ Cache أولاً
    cached = student_cache.get(f"student_{student_id}")
    if cached:
        print(f"📦 من الـ Cache: {student_id}")
        return cached
    
    # جلب من قاعدة البيانات
    data = supabase.table('students').select('*').eq('id', student_id).execute()
    
    if data.data:
        # حفظ في الـ Cache
        student_cache.set(f"student_{student_id}", data.data[0], ttl_seconds=1800)
        print(f"💾 حفظ في الـ Cache: {student_id}")
    
    return data

# مثال على التنظيف:
expired_count = student_cache.clear_expired()
print(f"🧹 تم مسح {expired_count} عناصر منتهية الصلاحية")


# ═══════════════════════════════════════════════════════════════════════════════
# مثال 7: نظام Pagination
# ═══════════════════════════════════════════════════════════════════════════════

"""
البدل الحالي:
    def callback_top_students(call, page=1):
        all_students = get_top_10_students()  # جميعهم في رسالة واحدة!
        bot.send_message(call.from_user.id, format_list(all_students))

بالتحسين الجديد:
"""

from improvements import PaginatedResults

def callback_top_students(call):
    user_id = call.from_user.id
    all_students = get_top_10_students()
    
    # إعداد pagination (10 طلاب في الصفحة)
    paginator = PaginatedResults(all_students, page_size=10)
    
    # الصفحة الأولى
    page_num = 1
    students, current_page, total_pages = paginator.get_page(page_num)
    
    # بناء الرسالة
    header = paginator.format_header(current_page, "🏆 أفضل الطلاب")
    content = "\n".join([f"{i+1}. {s['name']} - {s['avg']}" for i, s in enumerate(students)])
    
    # الأزرار
    markup = types.InlineKeyboardMarkup()
    if current_page > 1:
        markup.add(types.InlineKeyboardButton("⬅️ السابق", callback_data=f"page_{current_page-1}"))
    if current_page < total_pages:
        markup.add(types.InlineKeyboardButton("التالي ➡️", callback_data=f"page_{current_page+1}"))
    
    bot.send_message(user_id, header + content, reply_markup=markup)


# ═══════════════════════════════════════════════════════════════════════════════
# مثال 8: مراقبة صحة قاعدة البيانات
# ═══════════════════════════════════════════════════════════════════════════════

"""
البدل الحالي:
    # لا يوجد فحص لصحة الاتصال

بالتحسين الجديد:
"""

from improvements import DatabaseHealthMonitor

# تهيئة مراقب الصحة
db_monitor = DatabaseHealthMonitor(supabase, check_interval=300)

# قبل أي عملية مهمة:
def send_student_result_safe(user_id, student_id):
    if not db_monitor.check_connection():
        bot.send_message(user_id, "❌ قاعدة البيانات غير متاحة حالياً")
        db_logger.warning("قاعدة البيانات معطلة", user_id=user_id)
        return
    
    # الحصول على البيانات
    data = get_student_data_cached(student_id)
    bot.send_message(user_id, format_result(data))

# عرض حالة الاتصال:
status = db_monitor.get_status()
# {'healthy': True, 'error_count': 0, 'last_check': '2026-04-01T10:30:45'}


# ═══════════════════════════════════════════════════════════════════════════════
# مثال 9: معدل الطلبات (Rate Limiting)
# ═══════════════════════════════════════════════════════════════════════════════

"""
البدل الحالي:
    @bot.message_handler(commands=['ask'])
    def handle_ask(message):
        response = ai_service.ask(message.text)
        # المستخدم قد يرسل 100 سؤال في الثانية!

بالتحسين الجديد:
"""

from improvements import RateLimiter

# 10 أسئلة كل 60 ثانية
ask_limiter = RateLimiter(max_requests=10, window_seconds=60)

@bot.message_handler(commands=['ask'])
def handle_ask(message):
    user_id = message.from_user.id
    
    # التحقق من الحد
    is_allowed, remaining = ask_limiter.is_allowed(user_id)
    
    if not is_allowed:
        wait_time = ask_limiter.get_wait_time(user_id)
        bot.send_message(
            user_id,
            f"⏸️ لقد وصلت للحد الأقصى من الأسئلة!\nحاول بعد {wait_time} ثانية"
        )
        return
    
    # معالجة السؤال
    response = ai_service.ask(message.text)
    bot.send_message(user_id, response)
    
    # عرض عدد الطلبات المتبقية
    if remaining <= 3:
        bot.send_message(user_id, f"⚠️ {remaining} أسئلة متبقية")


# ═══════════════════════════════════════════════════════════════════════════════
# مثال 10: تخزين مؤقت للنتائج الثقيلة
# ═══════════════════════════════════════════════════════════════════════════════

"""
البدل الحالي:
    def callback_stats(call):
        student_data = get_student_data(student_id)
        stats = calculate_statistics(student_data)
        charts = create_charts(stats)
        # كل مرة يتم الحساب من جديد!

بالتحسين الجديد:
"""

from improvements import ResultCache

result_cache = ResultCache(ttl_seconds=1800)  # 30 دقيقة

def callback_stats_cached(call):
    student_id = call.from_user.id
    user_id = call.from_user.id
    
    # البحث في الـ Cache
    cached_result = result_cache.get_student_result(student_id)
    if cached_result:
        print(f"📦 من الـ Cache: الإحصائيات")
        send_cached_stats(bot, user_id, cached_result)
        return
    
    # الحساب الكامل
    student_data = get_student_data(student_id)
    stats = calculate_statistics(student_data)
    charts = create_charts(stats)
    
    result = {'stats': stats, 'charts': charts}
    
    # حفظ في الـ Cache
    result_cache.set_student_result(student_id, result)
    print(f"💾 حفظ في الـ Cache: الإحصائيات")
    
    send_cached_stats(bot, user_id, result)


# ═══════════════════════════════════════════════════════════════════════════════
# مثال 11-20: الميزات المتقدمة
# ═══════════════════════════════════════════════════════════════════════════════

# 🔟 في أعلى الملف الرئيسي:
from improvements_advanced import (
    APIResponseTimeMonitor,
    AsyncDatabaseOperations,
    QueryResultCompression,
    UserActivityTracker,
    BatchProcessor,
    GracefulDegradationMode,
    CircuitBreaker,
    AutomatedHealthChecker
)

# تهيئة الأنظمة المتقدمة
api_monitor = APIResponseTimeMonitor()
async_db = AsyncDatabaseOperations(max_workers=5)
activity_tracker = UserActivityTracker(supabase)
batch_processor = BatchProcessor(batch_size=100)
degradation_mode = GracefulDegradationMode()
circuit_breaker = CircuitBreaker(failure_threshold=5)
health_checker = AutomatedHealthChecker(bot, supabase, ADMIN_IDS, check_interval=300)

# بدء الفحوصات الصحية
health_checker.start()

# 🔟 تتبع النشاط:
@bot.message_handler(commands=['ask'])
def handle_ask(message):
    user_id = message.from_user.id
    
    # تتبع الفعل
    activity_tracker.track_action(
        user_id,
        'ask_question',
        {'question_length': len(message.text)}
    )
    
    # الرد...


# ═══════════════════════════════════════════════════════════════════════════════
# 📝 ملخص التطبيق
# ═══════════════════════════════════════════════════════════════════════════════

"""
خطوات التطبيق السريعة:

1. 📥 استيراد المكتبات:
   from improvements import *
   from improvements_advanced import *

2. 🔧 التهيئة (بعد إنشاء bot و supabase):
   db_logger = DatabaseLogger()
   error_handler = ErrorHandler(bot, ADMIN_IDS, db_logger)
   student_cache = AdvancedCache()
   db_monitor = DatabaseHealthMonitor(supabase)
   ask_limiter = RateLimiter(max_requests=10, window_seconds=60)
   
3. ✨ التطبيق:
   - استخدم @retry_with_backoff على الدوال الثقيلة
   - استخدم InputValidator للتحقق من المدخلات
   - استخدم MessageSplitter للرسائل الطويلة
   - استخدم error_handler لمعالجة الأخطاء
   - استخدم AdvancedCache للنتائج المكررة

4. 📊 المراقبة:
   - اطلب تقرير الأداء: performance_monitor.get_report()
   - اطلب حالة الـ Cache: student_cache.stats()
   - اطلب حالة قاعدة البيانات: db_monitor.get_status()
   
5. 🏥 الصحة:
   - health_checker.get_health_report()
   - degradation_mode.get_status_message()
"""

print("✅ دليل التطبيق العملي - جاهز!")
print("📚 راجع أمثلة الاستخدام أعلاه لدمج التحسينات بسهولة")
