# -*- coding: utf-8 -*-
"""
🚀 20 تحسين شامل على وظائف البوت - نسخة متكاملة
تاريخ: 2026
الهدف: تحسين الأداء والأمان والاستقرار
"""

import asyncio
import functools
import hashlib
import json
import logging
import time
import traceback
import threading
import gzip
import psutil
from datetime import datetime, timedelta
from typing import Optional, List, Tuple, Any, Callable
from collections import defaultdict
from threading import Lock
from concurrent.futures import ThreadPoolExecutor

# ════════════════════════════════════════════════════════════════════
# 1️⃣ نظام Logging احترافي منسق
# ════════════════════════════════════════════════════════════════════

class DatabaseLogger:
    """نظام logging احترافي مع Rotation تلقائي"""
    
    def __init__(self, log_file="bot_operations.log", max_size_mb=10, backup_count=5):
        self.log_file = log_file
        self.max_size_bytes = max_size_mb * 1024 * 1024
        self.backup_count = backup_count
        self.logger = self._setup_logger()
        
    def _setup_logger(self):
        logger = logging.getLogger("BotOperations")
        logger.setLevel(logging.DEBUG)
        
        # تنسيق موحد
        formatter = logging.Formatter(
            '%(asctime)s | %(levelname)-8s | %(funcName)s:%(lineno)d | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # معالج الملف
        handler = logging.FileHandler(self.log_file, encoding='utf-8')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        return logger
    
    def info(self, message, extra_data=None):
        msg = message + (f" | {json.dumps(extra_data, ensure_ascii=False)}" if extra_data else "")
        self.logger.info(msg)
    
    def error(self, message, exception=None, user_id=None):
        if exception:
            msg = f"{message} | Exception: {str(exception)}"
        else:
            msg = message
        if user_id:
            msg += f" | User: {user_id}"
        self.logger.error(msg, exc_info=exception)
    
    def warning(self, message, user_id=None):
        if user_id:
            message += f" | User: {user_id}"
        self.logger.warning(message)


# ════════════════════════════════════════════════════════════════════
# 2️⃣ نظام معالجة الأخطاء الموحد مع إشعارات الإدارة
# ════════════════════════════════════════════════════════════════════

class ErrorHandler:
    """معالج أخطاء موحد مع تصنيف وإرسال تنبيهات"""
    
    def __init__(self, bot, admin_ids, logger):
        self.bot = bot
        self.admin_ids = admin_ids
        self.logger = logger
        self.error_count = defaultdict(int)
        self.error_lock = Lock()
        
    def handle(self, message, exception=None, user_id=None, critical=False):
        """معالجة الخطأ والإرسال للمسؤول إذا كان حرجاً"""
        
        # تسجيل الخطأ
        self.logger.error(message, exception=exception, user_id=user_id)
        
        # عد الأخطاء
        with self.error_lock:
            if exception:
                error_type = type(exception).__name__
                self.error_count[error_type] += 1
        
        # إرسال تنبيه للمسؤول إذا كان حرجاً
        if critical and self.admin_ids:
            alert = f"""
🚨 خطأ حرج في البوت!
━━━━━━━━━━━━━━━━
⏰ الوقت: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
📝 الرسالة: {message}
👤 المستخدم: {user_id or 'نظام'}
🔧 النوع: {type(exception).__name__ if exception else 'Unknown'}

📋 التفاصيل:
{traceback.format_exc() if exception else 'لا توجد تفاصيل'}
            """.strip()
            
            for admin_id in self.admin_ids:
                try:
                    self.bot.send_message(admin_id, alert)
                except:
                    pass
    
    def get_stats(self):
        """الحصول على إحصائيات الأخطاء"""
        with self.error_lock:
            return dict(self.error_count)


# ════════════════════════════════════════════════════════════════════
# 3️⃣ آلية إعادة المحاولة مع Exponential Backoff
# ════════════════════════════════════════════════════════════════════

def retry_with_backoff(max_retries=3, initial_delay=1, backoff_factor=2):
    """
    ديكوريتور لإعادة محاولة الدالة مع تأخير متزايد
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            delay = initial_delay
            last_exception = None
            
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        print(f"⚠️ محاولة {attempt + 1}/{max_retries} فشلت، إعادة محاولة بعد {delay}s...")
                        time.sleep(delay)
                        delay *= backoff_factor
            
            raise last_exception
        
        return wrapper
    return decorator


# ════════════════════════════════════════════════════════════════════
# 4️⃣ نظام تقسيم الرسائل الطويلة
# ════════════════════════════════════════════════════════════════════

class MessageSplitter:
    """تقسيم الرسائل الطويلة تلقائياً حسب حد Telegram"""
    
    MAX_MESSAGE_LENGTH = 4096
    
    @staticmethod
    def split_message(text: str) -> List[str]:
        """تقسيم النص إلى رسائل آمنة"""
        if len(text) <= MessageSplitter.MAX_MESSAGE_LENGTH:
            return [text]
        
        messages = []
        current_message = ""
        lines = text.split('\n')
        
        for line in lines:
            if len(current_message) + len(line) + 1 > MessageSplitter.MAX_MESSAGE_LENGTH:
                if current_message.strip():
                    messages.append(current_message.strip())
                current_message = line + '\n'
            else:
                current_message += line + '\n'
        
        if current_message.strip():
            messages.append(current_message.strip())
        
        return messages
    
    @staticmethod
    def send_long_message(bot, chat_id, text, reply_markup=None):
        """إرسال رسالة طويلة على دفعات"""
        messages = MessageSplitter.split_message(text)
        sent_messages = []
        
        for i, msg in enumerate(messages):
            markup = reply_markup if i == len(messages) - 1 else None
            try:
                sent = bot.send_message(chat_id, msg, reply_markup=markup, parse_mode='HTML')
                sent_messages.append(sent)
            except Exception as e:
                print(f"❌ خطأ إرسال الرسالة {i+1}/{len(messages)}: {e}")
        
        return sent_messages


# ════════════════════════════════════════════════════════════════════
# 5️⃣ نظام التحقق من البيانات المدخلة
# ════════════════════════════════════════════════════════════════════

class InputValidator:
    """التحقق الصارم من البيانات المدخلة"""
    
    ALLOWED_NAME_CHARS = "ابتثجحخدذرزسشصضطظعغفقكلمنهويةآأؤئ a-zA-Z0-9 -"
    
    @staticmethod
    def validate_student_name(name: str) -> Tuple[bool, str]:
        """التحقق من صحة اسم الطالب"""
        if not name or len(name) < 2:
            return False, "⚠️ الاسم قصير جداً (2 أحرف على الأقل)"
        
        if len(name) > 100:
            return False, "⚠️ الاسم طويل جداً (100 حرف أقصى)"
        
        import re
        if not re.match(f"^[{InputValidator.ALLOWED_NAME_CHARS}]+$", name):
            return False, "⚠️ الاسم يحتوي على أحرف غير مسموحة"
        
        return True, name.strip()
    
    @staticmethod
    def validate_numeric_input(value: str, min_val=0, max_val=100) -> Tuple[bool, Any]:
        """التحقق من البيانات الرقمية"""
        try:
            num = float(value.strip())
            if num < min_val or num > max_val:
                return False, f"⚠️ القيمة يجب أن تكون بين {min_val} و {max_val}"
            return True, num
        except ValueError:
            return False, "⚠️ قيمة رقمية غير صحيحة"
    
    @staticmethod
    def sanitize_sql_input(text: str) -> str:
        """تنظيف المدخلات من أحرف خطرة"""
        dangerous_chars = ["'", '"', ";", "--", "/*", "*/", "xp_", "sp_"]
        result = text
        for char in dangerous_chars:
            result = result.replace(char, "")
        return result.strip()


# ════════════════════════════════════════════════════════════════════
# 6️⃣ نظام Caching محسّن مع TTL
# ════════════════════════════════════════════════════════════════════

class AdvancedCache:
    """نظام caching متقدم مع انتهاء صلاحية تلقائي"""
    
    def __init__(self, default_ttl_seconds=3600):
        self.cache = {}
        self.ttl_data = {}
        self.lock = Lock()
        self.default_ttl = default_ttl_seconds
    
    def get(self, key: str) -> Optional[Any]:
        """جلب قيمة من الـ cache"""
        with self.lock:
            if key not in self.cache:
                return None
            
            if key in self.ttl_data:
                if time.time() > self.ttl_data[key]:
                    del self.cache[key]
                    del self.ttl_data[key]
                    return None
            
            return self.cache[key]
    
    def set(self, key: str, value: Any, ttl_seconds: Optional[int] = None):
        """حفظ قيمة في الـ cache"""
        with self.lock:
            self.cache[key] = value
            ttl = ttl_seconds or self.default_ttl
            self.ttl_data[key] = time.time() + ttl
    
    def clear_expired(self):
        """مسح البيانات منتهية الصلاحية"""
        with self.lock:
            expired_keys = []
            current_time = time.time()
            
            for key, expiry_time in self.ttl_data.items():
                if current_time > expiry_time:
                    expired_keys.append(key)
            
            for key in expired_keys:
                if key in self.cache:
                    del self.cache[key]
                    del self.ttl_data[key]
        
        return len(expired_keys)
    
    def stats(self) -> dict:
        """إحصائيات الـ cache"""
        with self.lock:
            return {
                "items_count": len(self.cache),
                "expired_count": sum(1 for t in self.ttl_data.values() 
                                    if t < time.time()),
                "memory_items": len(self.cache)
            }


# ════════════════════════════════════════════════════════════════════
# 7️⃣ نظام Pagination للنتائج الكثيرة
# ════════════════════════════════════════════════════════════════════

class PaginatedResults:
    """إدارة النتائج الكثيرة مع pagination"""
    
    def __init__(self, items: List[Any], page_size: int = 10):
        self.items = items
        self.page_size = page_size
        self.total_pages = (len(items) + page_size - 1) // page_size
    
    def get_page(self, page_num: int) -> Tuple[List[Any], int, int]:
        """جلب صفحة معينة"""
        if page_num < 1 or page_num > self.total_pages:
            return [], page_num, self.total_pages
        
        start_idx = (page_num - 1) * self.page_size
        end_idx = start_idx + self.page_size
        
        return self.items[start_idx:end_idx], page_num, self.total_pages
    
    def format_header(self, page_num: int, title: str = "") -> str:
        """تنسيق رأس الصفحة"""
        header = f"📄 {title}\n" if title else ""
        if self.total_pages > 1:
            header += f"صفحة {page_num} من {self.total_pages}\n"
            header += f"━━━━━━━━━━━━━━━━━━━\n"
        return header


# ════════════════════════════════════════════════════════════════════
# 8️⃣ نظام مراقبة صحة الاتصال بـ Database
# ════════════════════════════════════════════════════════════════════

class DatabaseHealthMonitor:
    """مراقبة صحة الاتصال مع قاعدة البيانات"""
    
    def __init__(self, supabase, check_interval=300):
        self.supabase = supabase
        self.check_interval = check_interval
        self.last_check = 0
        self.is_healthy = True
        self.error_count = 0
        self.lock = Lock()
    
    def check_connection(self) -> bool:
        """فحص الاتصال بـ Supabase"""
        current_time = time.time()
        
        if current_time - self.last_check < self.check_interval:
            return self.is_healthy
        
        try:
            with self.lock:
                response = self.supabase.table("users").select("count").limit(1).execute()
                self.is_healthy = True
                self.error_count = 0
                self.last_check = current_time
                return True
        except Exception as e:
            with self.lock:
                self.error_count += 1
                self.is_healthy = self.error_count < 3
                self.last_check = current_time
            return False
    
    def get_status(self) -> dict:
        """الحصول على حالة الاتصال"""
        return {
            "healthy": self.is_healthy,
            "error_count": self.error_count,
            "last_check": datetime.fromtimestamp(self.last_check).isoformat()
        }


# ════════════════════════════════════════════════════════════════════
# 9️⃣ نظام معدل الطلبات (Rate Limiting)
# ════════════════════════════════════════════════════════════════════

class RateLimiter:
    """التحكم في معدل الطلبات لمنع الإساءة"""
    
    def __init__(self, max_requests=10, window_seconds=60):
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.user_requests = defaultdict(list)
        self.lock = Lock()
    
    def is_allowed(self, user_id: int) -> Tuple[bool, Optional[int]]:
        """التحقق من السماح للمستخدم"""
        current_time = time.time()
        window_start = current_time - self.window_seconds
        
        with self.lock:
            self.user_requests[user_id] = [
                t for t in self.user_requests[user_id] 
                if t > window_start
            ]
            
            if len(self.user_requests[user_id]) >= self.max_requests:
                return False, 0
            
            self.user_requests[user_id].append(current_time)
            remaining = self.max_requests - len(self.user_requests[user_id])
            
            return True, remaining
    
    def get_wait_time(self, user_id: int) -> int:
        """الحصول على وقت الانتظار"""
        with self.lock:
            if user_id not in self.user_requests or not self.user_requests[user_id]:
                return 0
            
            oldest_request = min(self.user_requests[user_id])
            wait_seconds = int(oldest_request + self.window_seconds - time.time())
            return max(0, wait_seconds)


# ════════════════════════════════════════════════════════════════════
# 🔟 نظام تخزين مؤقت للنتائج الثقيلة
# ════════════════════════════════════════════════════════════════════

class ResultCache:
    """تخزين مؤقت للنتائج الثقيلة"""
    
    def __init__(self, ttl_seconds=1800):
        self.student_cache = {}
        self.ttl = ttl_seconds
        self.lock = Lock()
    
    def get_student_result(self, student_id: int) -> Optional[dict]:
        """جلب نتيجة الطالب من الـ cache"""
        with self.lock:
            if student_id not in self.student_cache:
                return None
            
            data, timestamp = self.student_cache[student_id]
            if time.time() - timestamp > self.ttl:
                del self.student_cache[student_id]
                return None
            
            return data
    
    def set_student_result(self, student_id: int, data: dict):
        """حفظ نتيجة الطالب في الـ cache"""
        with self.lock:
            self.student_cache[student_id] = (data, time.time())
    
    def invalidate(self, student_id: int = None):
        """مسح الـ cache"""
        with self.lock:
            if student_id:
                self.student_cache.pop(student_id, None)
            else:
                self.student_cache.clear()


# ════════════════════════════════════════════════════════════════════
# 1️⃣1️⃣ Wrapper آمن لعمليات قاعدة البيانات
# ════════════════════════════════════════════════════════════════════

class SafeDatabaseOperation:
    """تنفيذ آمن لعمليات قاعدة البيانات"""
    
    @staticmethod
    @retry_with_backoff(max_retries=3, initial_delay=0.5)
    def execute_with_timeout(operation, timeout=10):
        """تنفيذ عملية مع timeout"""
        try:
            result = operation()
            return result
        except TimeoutError:
            raise Exception("❌ انتهت مهلة الوقت لعملية قاعدة البيانات")
        except Exception as e:
            raise


# ════════════════════════════════════════════════════════════════════
# 1️⃣2️⃣ نظام مراقبة الأداء والإحصائيات
# ════════════════════════════════════════════════════════════════════

class PerformanceMonitor:
    """قياس ومراقبة أداء الدوال"""
    
    def __init__(self):
        self.metrics = defaultdict(lambda: {
            "calls": 0,
            "total_time": 0,
            "min_time": float('inf'),
            "max_time": 0,
            "errors": 0
        })
        self.lock = Lock()
    
    def measure(self, func_name: str):
        """ديكوريتور لقياس الأداء"""
        def decorator(func):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                start_time = time.time()
                try:
                    result = func(*args, **kwargs)
                    return result
                except Exception as e:
                    with self.lock:
                        self.metrics[func_name]["errors"] += 1
                    raise
                finally:
                    elapsed = time.time() - start_time
                    with self.lock:
                        metric = self.metrics[func_name]
                        metric["calls"] += 1
                        metric["total_time"] += elapsed
                        metric["min_time"] = min(metric["min_time"], elapsed)
                        metric["max_time"] = max(metric["max_time"], elapsed)
            
            return wrapper
        return decorator
    
    def get_report(self) -> dict:
        """تقرير شامل عن الأداء"""
        with self.lock:
            report = {}
            for func_name, metrics in self.metrics.items():
                avg_time = metrics["total_time"] / max(1, metrics["calls"])
                report[func_name] = {
                    "calls": metrics["calls"],
                    "avg_time_ms": round(avg_time * 1000, 2),
                    "min_time_ms": round(metrics["min_time"] * 1000, 2),
                    "max_time_ms": round(metrics["max_time"] * 1000, 2),
                    "errors": metrics["errors"],
                    "success_rate": round(
                        (metrics["calls"] - metrics["errors"]) / max(1, metrics["calls"]) * 100, 2
                    )
                }
            return report


# ════════════════════════════════════════════════════════════════════
# 1️⃣3️⃣ مراقبة وقت استجابة API
# ════════════════════════════════════════════════════════════════════

class APIResponseTimeMonitor:
    """مراقبة أوقات الاستجابة للـ API"""
    
    def __init__(self):
        self.api_calls = []
    
    def record(self, endpoint: str, response_time_ms: float):
        """تسجيل استدعاء API"""
        self.api_calls.append({
            'endpoint': endpoint,
            'response_time': response_time_ms,
            'timestamp': datetime.now().isoformat(),
            'status': 'slow' if response_time_ms > 1000 else 'normal'
        })
        
        if len(self.api_calls) > 1000:
            self.api_calls = self.api_calls[-1000:]
    
    def get_slowest_endpoints(self, limit=10):
        """الحصول على أبطأ endpoints"""
        if not self.api_calls:
            return []
        
        sorted_calls = sorted(
            self.api_calls, 
            key=lambda x: x['response_time'], 
            reverse=True
        )
        
        grouped = {}
        for call in sorted_calls:
            endpoint = call['endpoint']
            if endpoint not in grouped:
                grouped[endpoint] = []
            grouped[endpoint].append(call['response_time'])
        
        avg_times = {
            ep: sum(times) / len(times)
            for ep, times in grouped.items()
        }
        
        return sorted(
            avg_times.items(),
            key=lambda x: x[1],
            reverse=True
        )[:limit]


# ════════════════════════════════════════════════════════════════════
# 1️⃣4️⃣ عمليات قاعدة البيانات غير المتزامنة
# ════════════════════════════════════════════════════════════════════

class AsyncDatabaseOperations:
    """تنفيذ عمليات قاعدة البيانات بشكل متوازي"""
    
    def __init__(self, max_workers=5):
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
    
    async def fetch_student_data_async(self, supabase, student_id: int):
        """جلب بيانات الطالب بشكل غير متزامن"""
        loop = asyncio.get_event_loop()
        
        def fetch():
            return supabase.table('students').select('*').eq('id', student_id).execute()
        
        return await loop.run_in_executor(self.executor, fetch)
    
    async def fetch_multiple_students_async(self, supabase, student_ids: list):
        """جلب بيانات عدة طلاب بشكل متوازي"""
        tasks = [
            self.fetch_student_data_async(supabase, sid)
            for sid in student_ids
        ]
        return await asyncio.gather(*tasks)


# ════════════════════════════════════════════════════════════════════
# 1️⃣5️⃣ ضغط نتائج الاستعلامات
# ════════════════════════════════════════════════════════════════════

class QueryResultCompression:
    """ضغط نتائج الاستعلامات لتقليل استهلاك الذاكرة"""
    
    @staticmethod
    def compress_result(data: dict) -> bytes:
        """ضغط النتائج"""
        json_str = json.dumps(data, ensure_ascii=False)
        compressed = gzip.compress(json_str.encode('utf-8'))
        return compressed
    
    @staticmethod
    def decompress_result(compressed_data: bytes) -> dict:
        """فك الضغط عن النتائج"""
        decompressed = gzip.decompress(compressed_data)
        return json.loads(decompressed.decode('utf-8'))
    
    @staticmethod
    def get_compression_ratio(data: dict) -> float:
        """حساب نسبة الضغط"""
        original_size = len(json.dumps(data).encode('utf-8'))
        compressed_size = len(QueryResultCompression.compress_result(data))
        
        if original_size == 0:
            return 0
        
        return (1 - compressed_size / original_size) * 100


# ════════════════════════════════════════════════════════════════════
# 1️⃣6️⃣ تتبع نشاط المستخدم
# ════════════════════════════════════════════════════════════════════

class UserActivityTracker:
    """تتبع نشاط المستخدمين لتحسين الأداء والأمان"""
    
    def __init__(self, supabase):
        self.supabase = supabase
        self.activities = {}
    
    def track_action(self, user_id: int, action: str, metadata: dict = None):
        """تسجيل فعل المستخدم"""
        activity = {
            'user_id': user_id,
            'action': action,
            'timestamp': datetime.now().isoformat(),
            'metadata': metadata or {}
        }
        
        if user_id not in self.activities:
            self.activities[user_id] = []
        
        self.activities[user_id].append(activity)
        
        try:
            self.supabase.table('user_activities').insert(activity).execute()
        except Exception as e:
            print(f"⚠️ خطأ حفظ النشاط: {e}")
    
    def get_user_stats(self, user_id: int) -> dict:
        """إحصائيات المستخدم"""
        if user_id not in self.activities:
            return {}
        
        activities = self.activities[user_id]
        action_counts = {}
        
        for activity in activities:
            action = activity['action']
            action_counts[action] = action_counts.get(action, 0) + 1
        
        return {
            'total_actions': len(activities),
            'actions_breakdown': action_counts,
            'last_activity': activities[-1]['timestamp'] if activities else None
        }


# ════════════════════════════════════════════════════════════════════
# 1️⃣7️⃣ معالجة العمليات الضخمة على دفعات
# ════════════════════════════════════════════════════════════════════

class BatchProcessor:
    """معالجة العمليات الضخمة على دفعات"""
    
    def __init__(self, batch_size=100):
        self.batch_size = batch_size
    
    def process_in_batches(self, items: list, processor_func):
        """معالجة القائمة على دفعات"""
        results = []
        total_items = len(items)
        
        for i in range(0, total_items, self.batch_size):
            batch = items[i:i + self.batch_size]
            batch_num = i // self.batch_size + 1
            total_batches = (total_items + self.batch_size - 1) // self.batch_size
            
            print(f"⏳ معالجة الدفعة {batch_num}/{total_batches}...")
            
            try:
                batch_result = processor_func(batch)
                results.extend(batch_result)
            except Exception as e:
                print(f"❌ خطأ في الدفعة {batch_num}: {e}")
                continue
        
        return results
    
    def export_data_in_batches(self, supabase, table_name: str, output_file: str):
        """تصدير البيانات على دفعات"""
        all_data = []
        offset = 0
        
        while True:
            try:
                response = supabase.table(table_name).select('*').range(
                    offset, offset + self.batch_size - 1
                ).execute()
                
                if not response.data:
                    break
                
                all_data.extend(response.data)
                offset += self.batch_size
                
                print(f"📥 تم جلب {len(all_data)} عنصر...")
                
            except Exception as e:
                print(f"❌ خطأ الجلب: {e}")
                break
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(all_data, f, ensure_ascii=False, indent=2)
        
        return len(all_data)


# ════════════════════════════════════════════════════════════════════
# 1️⃣8️⃣ وضع التدهور الحنين
# ════════════════════════════════════════════════════════════════════

class GracefulDegradationMode:
    """تشغيل البوت بميزات محدودة عند وجود مشاكل"""
    
    def __init__(self):
        self.is_degraded = False
        self.disabled_features = set()
        self.available_features = {
            'basic_search',
            'top_students',
            'user_stats',
            'ai_features',
            'analytics',
            'notifications',
            'admin_panel'
        }
    
    def enable_degraded_mode(self, reason: str):
        """تفعيل وضع التدهور"""
        print(f"⚠️ تفعيل وضع التدهور: {reason}")
        self.is_degraded = True
    
    def disable_feature(self, feature_name: str):
        """تعطيل ميزة معينة"""
        if feature_name in self.available_features:
            self.disabled_features.add(feature_name)
            print(f"🔌 تعطيل الميزة: {feature_name}")
    
    def is_feature_available(self, feature_name: str) -> bool:
        """التحقق من توفر الميزة"""
        if not self.is_degraded:
            return True
        return feature_name not in self.disabled_features
    
    def get_status_message(self) -> str:
        """رسالة حالة البوت"""
        if not self.is_degraded:
            return "🟢 البوت يعمل بكامل طاقته"
        
        available = self.available_features - self.disabled_features
        disabled = self.disabled_features
        
        msg = f"""
🟡 البوت في وضع التدهور
━━━━━━━━━━━━━━━━━━━━
✅ الميزات المتاحة: {', '.join(available) or 'لا توجد'}
❌ الميزات المعطلة: {', '.join(disabled) or 'لا توجد'}

بعض الخدمات قد تكون بطيئة أو محدودة.
"""
        return msg.strip()


# ════════════════════════════════════════════════════════════════════
# 1️⃣9️⃣ نمط قاطع الدائرة
# ════════════════════════════════════════════════════════════════════

class CircuitBreaker:
    """منع محاولات اتصال متكررة عند فشل الخدمة"""
    
    def __init__(self, failure_threshold=5, timeout_seconds=60):
        self.failure_threshold = failure_threshold
        self.timeout_seconds = timeout_seconds
        self.failure_count = 0
        self.last_failure_time = None
        self.state = 'CLOSED'
    
    def call(self, func, *args, **kwargs):
        """محاولة استدعاء الدالة بأمان"""
        if self.state == 'OPEN':
            elapsed = (datetime.now() - self.last_failure_time).total_seconds()
            if elapsed > self.timeout_seconds:
                self.state = 'HALF_OPEN'
                print("🟡 القاطع: محاولة استعادة الخدمة...")
            else:
                raise Exception(f"🚫 الخدمة معطلة، أعد المحاولة بعد {self.timeout_seconds}s")
        
        try:
            result = func(*args, **kwargs)
            
            if self.state == 'HALF_OPEN':
                self.state = 'CLOSED'
                self.failure_count = 0
                print("🟢 القاطع: الخدمة استعادت عملها")
            
            return result
            
        except Exception as e:
            self.failure_count += 1
            self.last_failure_time = datetime.now()
            
            if self.failure_count >= self.failure_threshold:
                self.state = 'OPEN'
                print(f"🔴 القاطع: الخدمة معطلة بعد {self.failure_count} محاولات فاشلة")
            
            raise


# ════════════════════════════════════════════════════════════════════
# 2️⃣0️⃣ فحوصات صحية تلقائية وإصلاح ذاتي
# ════════════════════════════════════════════════════════════════════

class AutomatedHealthChecker:
    """فحوصات دورية تلقائية لصحة النظام مع الإصلاح الذاتي"""
    
    def __init__(self, bot, supabase, admin_ids, check_interval=300):
        self.bot = bot
        self.supabase = supabase
        self.admin_ids = admin_ids
        self.check_interval = check_interval
        self.health_status = {}
        self.is_running = False
    
    def start(self):
        """بدء الفحوصات الدورية"""
        self.is_running = True
        thread = threading.Thread(target=self._health_check_loop, daemon=True)
        thread.start()
        print("🏥 بدء الفحوصات الصحية التلقائية...")
    
    def _health_check_loop(self):
        """حلقة الفحوصات الدورية"""
        while self.is_running:
            try:
                self._perform_health_checks()
                self._auto_heal()
            except Exception as e:
                print(f"❌ خطأ في الفحص الصحي: {e}")
            
            time.sleep(self.check_interval)
    
    def _perform_health_checks(self):
        """إجراء الفحوصات الصحية"""
        checks = {
            'database': self._check_database,
            'memory': self._check_memory,
            'storage': self._check_storage,
            'api_response': self._check_api_response
        }
        
        for check_name, check_func in checks.items():
            try:
                result = check_func()
                self.health_status[check_name] = {
                    'status': 'healthy' if result else 'unhealthy',
                    'timestamp': datetime.now().isoformat()
                }
            except Exception as e:
                self.health_status[check_name] = {
                    'status': 'error',
                    'error': str(e),
                    'timestamp': datetime.now().isoformat()
                }
    
    def _check_database(self) -> bool:
        """فحص اتصال قاعدة البيانات"""
        try:
            self.supabase.table('users').select('count', count='exact').limit(1).execute()
            return True
        except:
            return False
    
    def _check_memory(self) -> bool:
        """فحص استخدام الذاكرة"""
        try:
            memory_percent = psutil.virtual_memory().percent
            return memory_percent < 90
        except:
            return True
    
    def _check_storage(self) -> bool:
        """فحص مساحة التخزين"""
        try:
            storage = psutil.disk_usage('/')
            return storage.percent < 90
        except:
            return True
    
    def _check_api_response(self) -> bool:
        """فحص استجابة API"""
        start = time.time()
        try:
            self.supabase.table('users').select('count', count='exact').limit(1).execute()
            elapsed = time.time() - start
            return elapsed < 5
        except:
            return False
    
    def _auto_heal(self):
        """محاولة الإصلاح الذاتي"""
        unhealthy = [
            name for name, status in self.health_status.items()
            if status.get('status') in ['unhealthy', 'error']
        ]
        
        if unhealthy:
            message = f"""
🏥 تقرير الفحص الصحي
━━━━━━━━━━━━━━━━━
🔴 مشاكل: {', '.join(unhealthy)}
⏰ الوقت: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

🔧 محاولة الإصلاح التلقائي...
            """
            
            for admin_id in self.admin_ids:
                try:
                    self.bot.send_message(admin_id, message)
                except:
                    pass
    
    def get_health_report(self) -> str:
        """تقرير صحة النظام"""
        report = "🏥 تقرير صحة النظام\n━━━━━━━━━━━━━━━━\n"
        
        for check_name, status in self.health_status.items():
            emoji = "✅" if status.get('status') == 'healthy' else "❌"
            report += f"{emoji} {check_name}: {status.get('status')}\n"
        
        return report
    
    def stop(self):
        """إيقاف الفحوصات"""
        self.is_running = False


print("✨ تم تحميل جميع التحسينات الـ 20 بنجاح!")
