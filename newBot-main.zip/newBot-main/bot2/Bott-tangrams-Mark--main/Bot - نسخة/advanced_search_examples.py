# -*- coding: utf-8 -*-
"""
🚀 أمثلة متقدمة للبحث التفاعلي
حالات استخدام خاصة + تخصيصات متقدمة
"""

# ═══════════════════════════════════════════════════════════════════════════════
# 1️⃣ البحث مع عرض تفاصيل معاينة في الأزرار
# ═══════════════════════════════════════════════════════════════════════════════

@bot.message_handler(commands=['search_preview'])
def handle_search_with_preview(message):
    """البحث مع عرض معلومات سريعة في الأزرار"""
    user_id = message.from_user.id
    text = message.text.replace('/search_preview', '').strip()
    
    if not text or len(text) < 2:
        bot.send_message(user_id, "❌ أدخل اسم الطالب")
        return
    
    try:
        response = supabase.table('students').select('*').ilike('name', f'%{text}%').limit(10).execute()
        results = response.data or []
    except Exception as e:
        bot.send_message(user_id, "❌ خطأ في البحث")
        return
    
    if not results:
        bot.send_message(user_id, f"❌ لا توجد نتائج عن '{text}'")
        return
    
    # أزرار مع معاينة
    keyboard = types.InlineKeyboardMarkup(row_width=1)
    
    for student in results:
        # معلومات سريعة
        gpa = student.get('gpa', '0')
        dept = student.get('department', 'N/A')
        
        btn_text = f"👤 {student['name']}\n   📍 {dept} | ⭐ {gpa}"
        
        keyboard.add(
            types.InlineKeyboardButton(
                text=btn_text,
                callback_data=f"select_student_{student['id']}"
            )
        )
    
    header = (
        f"🔍 <b>نتائج البحث</b> - {len(results)} نتيجة\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"البحث: <b>{text}</b>\n\n"
        f"<i>اختر من القائمة:</i>"
    )
    
    search_msg = bot.send_message(
        user_id,
        header,
        reply_markup=keyboard,
        parse_mode='HTML'
    )
    
    if not hasattr(bot, 'search_messages'):
        bot.search_messages = {}
    bot.search_messages[user_id] = search_msg.message_id


# ═══════════════════════════════════════════════════════════════════════════════
# 2️⃣ بحث متقدم مع تصنيف حسب القسم
# ═══════════════════════════════════════════════════════════════════════════════

@bot.message_handler(commands=['search_by_department'])
def handle_search_by_department(message):
    """البحث مع تجميع النتائج حسب القسم"""
    user_id = message.from_user.id
    text = message.text.replace('/search_by_department', '').strip()
    
    if not text or len(text) < 2:
        bot.send_message(user_id, "❌ أدخل اسم الطالب")
        return
    
    try:
        response = supabase.table('students').select('*').ilike('name', f'%{text}%').execute()
        results = response.data or []
    except Exception as e:
        bot.send_message(user_id, "❌ خطأ في البحث")
        return
    
    if not results:
        bot.send_message(user_id, f"❌ لا توجد نتائج")
        return
    
    # تجميع حسب القسم
    by_department = {}
    
    for student in results:
        dept = student.get('department', 'بدون قسم')
        if dept not in by_department:
            by_department[dept] = []
        by_department[dept].append(student)
    
    # بناء الأزرار
    keyboard = types.InlineKeyboardMarkup(row_width=1)
    
    for dept, students in sorted(by_department.items()):
        dept_label = f"📚 {dept} ({len(students)})"
        keyboard.add(types.InlineKeyboardButton(dept_label, callback_data=f"dept_{dept}"))
        
        for student in students:
            btn = types.InlineKeyboardButton(
                f"  └─ {student['name']}",
                callback_data=f"select_student_{student['id']}"
            )
            keyboard.add(btn)
    
    message_text = f"🔍 <b>البحث عن: {text}</b>\n━━━━━━━━━━━━━\n✅ عدد النتائج: {len(results)}"
    
    search_msg = bot.send_message(
        user_id,
        message_text,
        reply_markup=keyboard,
        parse_mode='HTML'
    )
    
    if not hasattr(bot, 'search_messages'):
        bot.search_messages = {}
    bot.search_messages[user_id] = search_msg.message_id


# ═══════════════════════════════════════════════════════════════════════════════
# 3️⃣ بحث ذكي - اقتراحات تصحيح تلقائي
# ═══════════════════════════════════════════════════════════════════════════════

from difflib import get_close_matches

@bot.message_handler(commands=['search_smart'])
def handle_search_smart(message):
    """بحث ذكي مع اقتراحات"""
    user_id = message.from_user.id
    text = message.text.replace('/search_smart', '').strip()
    
    if not text or len(text) < 2:
        bot.send_message(user_id, "❌ أدخل اسم الطالب")
        return
    
    try:
        response = supabase.table('students').select('name, id, student_id, gpa').execute()
        all_names = [s['name'] for s in response.data or []]
        
        # البحث الدقيق
        exact = supabase.table('students').select('*').ilike('name', f'%{text}%').execute()
        results = exact.data or []
        
        # البحث عن اقتراحات
        suggestions = get_close_matches(text, all_names, n=5, cutoff=0.6)
        
    except Exception as e:
        bot.send_message(user_id, "❌ خطأ في البحث")
        return
    
    # عرض النتائج أولاً
    keyboard = types.InlineKeyboardMarkup(row_width=1)
    
    if results:
        for student in results[:10]:
            keyboard.add(
                types.InlineKeyboardButton(
                    f"✓ {student['name']}",
                    callback_data=f"select_student_{student['id']}"
                )
            )
        
        message_text = f"✅ <b>نتائج مطابقة</b> ({len(results)})\n" if len(results) <= 10 else f"✅ أول 10 نتائج من {len(results)}\n"
    else:
        message_text = f"❌ لم يتم العثور على نتائج دقيقة\n\n"
    
    # عرض الاقتراحات
    if suggestions:
        message_text += f"\n💡 <b>هل قصدت:</b>\n"
        
        for suggest in suggestions:
            msg_text += f"• {suggest}\n"
            
            # الحصول على بيانات الاقتراح
            suggest_response = supabase.table('students').select('*').eq('name', suggest).limit(1).execute()
            if suggest_response.data:
                student = suggest_response.data[0]
                keyboard.add(
                    types.InlineKeyboardButton(
                        f"💡 {suggest}",
                        callback_data=f"select_student_{student['id']}"
                    )
                )
    
    search_msg = bot.send_message(
        user_id,
        message_text,
        reply_markup=keyboard,
        parse_mode='HTML'
    )
    
    if not hasattr(bot, 'search_messages'):
        bot.search_messages = {}
    bot.search_messages[user_id] = search_msg.message_id


# ═══════════════════════════════════════════════════════════════════════════════
# 4️⃣ بحث متوازن - البحث الديناميكي
# ═══════════════════════════════════════════════════════════════════════════════

@bot.message_handler(func=lambda message: message.text.startswith('بحث'))
def handle_inline_search(message):
    """البحث المباشر من أي رسالة تبدأ بـ 'بحث'"""
    user_id = message.from_user.id
    
    # استخراج الكلمة المبحوث عنها
    text = message.text.replace('بحث', '').strip()
    
    if not text or len(text) < 2:
        # إذا لم يكتب اسم، اطلب منه
        markup = types.ForceReply(selective=True)
        bot.send_message(
            user_id,
            "🔍 أدخل اسم الطالب:",
            reply_markup=markup
        )
        return
    
    # نفس منطق البحث
    try:
        response = supabase.table('students').select('*').ilike('name', f'%{text}%').limit(12).execute()
        results = response.data or []
    except Exception as e:
        bot.send_message(user_id, "❌ خطأ في البحث")
        return
    
    if not results:
        bot.send_message(user_id, f"❌ لا توجد نتائج عن '{text}'")
        return
    
    # عرض النتائج
    keyboard = types.InlineKeyboardMarkup(row_width=2)
    
    for i, student in enumerate(results):
        name = student['name'][:15]  # اختصار الاسم الطويل
        
        keyboard.add(
            types.InlineKeyboardButton(
                f"{i+1}. {name}",
                callback_data=f"select_student_{student['id']}"
            )
        )
    
    search_msg = bot.send_message(
        user_id,
        f"🔍 النتائج ({len(results)}):",
        reply_markup=keyboard
    )
    
    if not hasattr(bot, 'search_messages'):
        bot.search_messages = {}
    bot.search_messages[user_id] = search_msg.message_id


# ═══════════════════════════════════════════════════════════════════════════════
# 5️⃣ معالج متقدم - حفظ المفضلة من نتائج البحث
# ═══════════════════════════════════════════════════════════════════════════════

@bot.callback_query_handler(func=lambda call: call.data.startswith('favorite_'))
def handle_favorite(call):
    """إضافة للمفضلة من نتائج البحث"""
    user_id = call.from_user.id
    
    student_id = int(call.data.replace('favorite_', ''))
    
    try:
        # إضافة للمفضلة
        supabase.table('favorites').insert({
            'user_id': user_id,
            'student_id': student_id,
            'created_at': datetime.now().isoformat()
        }).execute()
        
        bot.answer_callback_query(call.id, "⭐ تم الإضافة للمفضلة!", show_alert=False)
        
    except Exception as e:
        bot.answer_callback_query(call.id, "❌ خطأ في الحفظ", show_alert=True)


# ═══════════════════════════════════════════════════════════════════════════════
# 6️⃣ معالج البحث المتكامل - مع كل الميزات
# ═══════════════════════════════════════════════════════════════════════════════

@bot.message_handler(commands=['search_full'])
def handle_search_full_featured(message):
    """البحث الكامل مع كل الميزات"""
    user_id = message.from_user.id
    text = message.text.replace('/search_full', '').strip()
    
    if not text or len(text) < 2:
        bot.send_message(user_id, "❌ أدخل اسم الطالب (حرفين على الأقل)")
        return
    
    # إرسال "يكتب..."
    bot.send_chat_action(user_id, 'typing')
    
    try:
        # البحث
        response = supabase.table('students').select('*').ilike('name', f'%{text}%').execute()
        results = response.data or []
        
        # الإحصائيات
        if results:
            avg_gpa = sum(float(s.get('gpa', 0)) for s in results) / len(results)
        else:
            avg_gpa = 0
        
    except Exception as e:
        bot.send_message(user_id, "❌ خطأ في البحث")
        return
    
    if not results:
        bot.send_message(user_id, f"❌ لا توجد نتائج عن '{text}'")
        return
    
    # بناء الرسالة الرئيسية
    message_text = f"""
🔍 <b>نتائج البحث الشاملة</b>
━━━━━━━━━━━━━━━━
🔎 البحث عن: <b>{text}</b>
📊 عدد النتائج: <b>{len(results)}</b>
⭐ المعدل المتوسط: <b>{avg_gpa:.2f}</b>

<i>اختر الطالب:</i>
"""
    
    # أزرار
    keyboard = types.InlineKeyboardMarkup(row_width=1)
    
    for student in results[:15]:
        gpa = student.get('gpa', '0')
        dept = student.get('department', 'N/A')
        
        btn_text = f"{student['name']} ({gpa} ⭐)"
        
        keyboard.add(
            types.InlineKeyboardButton(
                btn_text,
                callback_data=f"select_student_{student['id']}"
            )
        )
        
        # زر مفضلة
        keyboard.add(
            types.InlineKeyboardButton(
                "❤️ مفضلة",
                callback_data=f"favorite_{student['id']}"
            ),
            width=1
        )
    
    search_msg = bot.send_message(
        user_id,
        message_text,
        reply_markup=keyboard,
        parse_mode='HTML'
    )
    
    if not hasattr(bot, 'search_messages'):
        bot.search_messages = {}
    bot.search_messages[user_id] = search_msg.message_id
    
    # logging
    db_logger.info(
        f"بحث شامل: {text}",
        extra_data={'user_id': user_id, 'results': len(results), 'avg_gpa': avg_gpa}
    )


# ═══════════════════════════════════════════════════════════════════════════════
# ملخص الأمثلة المتقدمة
# ═══════════════════════════════════════════════════════════════════════════════

"""
✨ 6 أنماط بحث متقدمة:

1️⃣ /search_preview
   └─ عرض معاينة (قسم + معدل) في الأزرار

2️⃣ /search_by_department
   └─ تجميع النتائج حسب القسم

3️⃣ /search_smart
   └─ اقتراحات تصحيح تلقائي

4️⃣ كلمة بحث
   └─ بحث مباشر من أي رسالة

5️⃣ /search_full
   └─ بحث كامل + مفضلة + إحصائيات

كل نمط يناسب حالة استخدام مختلفة!
"""
