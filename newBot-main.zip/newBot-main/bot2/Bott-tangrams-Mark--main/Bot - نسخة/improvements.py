# -*- coding: utf-8 -*-
"""
🚀 20 تحسين شامل على وظائف البوت
تاريخ: 2026
الهدف: تحسين الأداء والأمان والاستقرار
"""

import asyncio
import functools
import hashlib
import json
import logging
import time
import traceback
from datetime import datetime, timedelta
from typing import Optional, List, Tuple, Any, Callable
from collections import defaultdict
from threading import Lock

# ═══════════════════════════════════════════════════════════════════
# 1️⃣ نظام Logging احترافي منمسق
# ═══════════════════════════════════════════════════════════════════

class DatabaseLogger:
    """نظام logging احترافي مع Rotation تلقائي"""
    
    def __init__(self, log_file="bot_operations.log", max_size_mb=10, backup_count=5):
        self.log_file = log_file
        self.max_size_bytes = max_size_mb * 1024 * 1024
        self.backup_count = backup_count
        self.logger = self._setup_logger()
        
    def _setup_logger(self):
        logger = logging.getLogger("BotOperations")
        logger.setLevel(logging.DEBUG)
        
        # تنسيق موحد
        formatter = logging.Formatter(
            '%(asctime)s | %(levelname)-8s | %(funcName)s:%(lineno)d | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # معالج الملf
        handler = logging.FileHandler(self.log_file, encoding='utf-8')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        return logger
    
    def info(self, message, extra_data=None):
        msg = message + (f" | {json.dumps(extra_data)}" if extra_data else "")
        self.logger.info(msg)
    
    def error(self, message, exception=None, user_id=None):
        if exception:
            msg = f"{message} | Exception: {str(exception)}"
        else:
            msg = message
        if user_id:
            msg += f" | User: {user_id}"
        self.logger.error(msg, exc_info=exception)
    
    def warning(self, message, user_id=None):
        if user_id:
            message += f" | User: {user_id}"
        self.logger.warning(message)


# ═══════════════════════════════════════════════════════════════════
# 2️⃣ نظام معالجة الأخطاء الموحد مع إشعارات الإدارة
# ═══════════════════════════════════════════════════════════════════

class ErrorHandler:
    """معالج أخطاء موحد مع تصنيف وإرسال تنبيهات"""
    
    def __init__(self, bot, admin_ids, logger):
        self.bot = bot
        self.admin_ids = admin_ids
        self.logger = logger
        self.error_count = defaultdict(int)
        self.error_lock = Lock()
        
    def handle(self, message, exception=None, user_id=None, critical=False):
        """معالجة الخطأ والإرسال للمسؤول إذا كان حرجاً"""
        
        # تسجيل الخطأ
        self.logger.error(message, exception=exception, user_id=user_id)
        
        # عد الأخطاء
        with self.error_lock:
            if exception:
                error_type = type(exception).__name__
                self.error_count[error_type] += 1
        
        # إرسال تنبيه للمسؤول إذا كان حرجاً
        if critical and self.admin_ids:
            alert = f"""
🚨 خطأ حرج في البوت!
━━━━━━━━━━━━━━━━
⏰ الوقت: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
📝 الرسالة: {message}
👤 المستخدم: {user_id or 'نظام'}
🔧 النوع: {type(exception).__name__ if exception else 'Unknown'}

📋 التفاصيل:
{traceback.format_exc() if exception else 'لا توجد تفاصيل'}
            """.strip()
            
            for admin_id in self.admin_ids:
                try:
                    self.bot.send_message(admin_id, alert)
                except:
                    pass
    
    def get_stats(self):
        """الحصول على إحصائيات الأخطاء"""
        with self.error_lock:
            return dict(self.error_count)


# ═══════════════════════════════════════════════════════════════════
# 3️⃣ آلية إعادة المحاولة مع Exponential Backoff
# ═══════════════════════════════════════════════════════════════════

def retry_with_backoff(max_retries=3, initial_delay=1, backoff_factor=2):
    """
    ديكوريتور لإعادة محاولة الدالة مع تأخير متزايد
    مثالاً: @retry_with_backoff(max_retries=3)
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            delay = initial_delay
            last_exception = None
            
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        print(f"⚠️ محاولة {attempt + 1}/{max_retries} فشلت، إعادة محاولة بعد {delay}s...")
                        time.sleep(delay)
                        delay *= backoff_factor
            
            raise last_exception
        
        return wrapper
    return decorator


# ═══════════════════════════════════════════════════════════════════
# 4️⃣ نظام تقسيم الرسائل الطويلة (4096 حرف)
# ═══════════════════════════════════════════════════════════════════

class MessageSplitter:
    """تقسيم الرسائل الطويلة تلقائياً حسب حد Telegram"""
    
    MAX_MESSAGE_LENGTH = 4096
    
    @staticmethod
    def split_message(text: str, max_lines=None) -> List[str]:
        """
        تقسيم النص إلى رسائل آمنة
        العودة: قائمة برسائل آمنة
        """
        if len(text) <= MessageSplitter.MAX_MESSAGE_LENGTH:
            return [text]
        
        messages = []
        current_message = ""
        lines = text.split('\n')
        
        for line in lines:
            if len(current_message) + len(line) + 1 > MessageSplitter.MAX_MESSAGE_LENGTH:
                if current_message.strip():
                    messages.append(current_message.strip())
                current_message = line + '\n'
            else:
                current_message += line + '\n'
        
        if current_message.strip():
            messages.append(current_message.strip())
        
        return messages
    
    @staticmethod
    def send_long_message(bot, chat_id, text, reply_markup=None):
        """إرسال رسالة طويلة على دفعات"""
        messages = MessageSplitter.split_message(text)
        sent_messages = []
        
        for i, msg in enumerate(messages):
            # إضافة الـ Markup فقط للرسالة الأخيرة
            markup = reply_markup if i == len(messages) - 1 else None
            try:
                sent = bot.send_message(chat_id, msg, reply_markup=markup, parse_mode='HTML')
                sent_messages.append(sent)
            except Exception as e:
                print(f"❌ خطأ إرسال الرسالة {i+1}/{len(messages)}: {e}")
        
        return sent_messages


# ═══════════════════════════════════════════════════════════════════
# 5️⃣ نظام التحقق من البيانات المدخلة (Input Validation)
# ═══════════════════════════════════════════════════════════════════

class InputValidator:
    """التحقق الصارم من البيانات المدخلة"""
    
    # الأحرف المسموحة في الأسماء
    ALLOWED_NAME_CHARS = "ابتثجحخدذرزسشصضطظعغفقكلمنهويةآأؤئ a-zA-Z0-9 -"
    
    @staticmethod
    def validate_student_name(name: str) -> Tuple[bool, str]:
        """التحقق من صحة اسم الطالب"""
        if not name or len(name) < 2:
            return False, "⚠️ الاسم قصير جداً (2 أحرف على الأقل)"
        
        if len(name) > 100:
            return False, "⚠️ الاسم طويل جداً (100 حرف أقصى)"
        
        # فحص الأحرف غير المسموحة
        import re
        if not re.match(f"^[{InputValidator.ALLOWED_NAME_CHARS}]+$", name):
            return False, "⚠️ الاسم يحتوي على أحرف غير مسموحة"
        
        return True, name.strip()
    
    @staticmethod
    def validate_numeric_input(value: str, min_val=0, max_val=100) -> Tuple[bool, Any]:
        """التحقق من البيانات الرقمية"""
        try:
            num = float(value.strip())
            if num < min_val or num > max_val:
                return False, f"⚠️ القيمة يجب أن تكون بين {min_val} و {max_val}"
            return True, num
        except ValueError:
            return False, "⚠️ قيمة رقمية غير صحيحة"
    
    @staticmethod
    def sanitize_sql_input(text: str) -> str:
        """تنظيف المدخلات من أحرف خطرة"""
        # استخدام parameterized queries بدلاً من التسلسل المباشر
        dangerous_chars = ["'", '"', ";", "--", "/*", "*/", "xp_", "sp_"]
        result = text
        for char in dangerous_chars:
            result = result.replace(char, "")
        return result.strip()


# ═══════════════════════════════════════════════════════════════════
# 6️⃣ نظام Caching محسّن مع TTL
# ═══════════════════════════════════════════════════════════════════

class AdvancedCache:
    """نظام caching متقدم مع انتهاء صلاحية تلقائي"""
    
    def __init__(self, default_ttl_seconds=3600):
        self.cache = {}
        self.ttl_data = {}
        self.lock = Lock()
        self.default_ttl = default_ttl_seconds
    
    def get(self, key: str) -> Optional[Any]:
        """جلب قيمة من الـ cache"""
        with self.lock:
            if key not in self.cache:
                return None
            
            # التحقق من انتهاء الصلاحية
            if key in self.ttl_data:
                if time.time() > self.ttl_data[key]:
                    del self.cache[key]
                    del self.ttl_data[key]
                    return None
            
            return self.cache[key]
    
    def set(self, key: str, value: Any, ttl_seconds: Optional[int] = None):
        """حفظ قيمة في الـ cache مع صلاحية محددة"""
        with self.lock:
            self.cache[key] = value
            ttl = ttl_seconds or self.default_ttl
            self.ttl_data[key] = time.time() + ttl
    
    def clear_expired(self):
        """مسح البيانات منتهية الصلاحية"""
        with self.lock:
            expired_keys = []
            current_time = time.time()
            
            for key, expiry_time in self.ttl_data.items():
                if current_time > expiry_time:
                    expired_keys.append(key)
            
            for key in expired_keys:
                if key in self.cache:
                    del self.cache[key]
                del self.ttl_data[key]
        
        return len(expired_keys)
    
    def stats(self) -> dict:
        """إحصائيات الـ cache"""
        with self.lock:
            return {
                "items_count": len(self.cache),
                "expired_count": sum(1 for t in self.ttl_data.values() 
                                    if t < time.time()),
                "memory_items": len(self.cache)
            }


# ═══════════════════════════════════════════════════════════════════
# 7️⃣ نظام Pagination للنتائج الكثيرة
# ═══════════════════════════════════════════════════════════════════

class PaginatedResults:
    """إدارة النتائج الكثيرة مع pagination"""
    
    def __init__(self, items: List[Any], page_size: int = 10):
        self.items = items
        self.page_size = page_size
        self.total_pages = (len(items) + page_size - 1) // page_size
    
    def get_page(self, page_num: int) -> Tuple[List[Any], int, int]:
        """
        جلب صفحة معينة
        العودة: (العناصر، رقم الصفحة الحالية، العدد الكلي للصفحات)
        """
        if page_num < 1 or page_num > self.total_pages:
            return [], page_num, self.total_pages
        
        start_idx = (page_num - 1) * self.page_size
        end_idx = start_idx + self.page_size
        
        return self.items[start_idx:end_idx], page_num, self.total_pages
    
    def format_header(self, page_num: int, title: str = "") -> str:
        """تنسيق رأس الصفحة"""
        header = f"📄 {title}\n" if title else ""
        if self.total_pages > 1:
            header += f"صفحة {page_num} من {self.total_pages}\n"
            header += f"━━━━━━━━━━━━━━━━━━━\n"
        return header


# ═══════════════════════════════════════════════════════════════════
# 8️⃣ نظام مراقبة صحة الاتصال بـ Database
# ═══════════════════════════════════════════════════════════════════

class DatabaseHealthMonitor:
    """مراقبة صحة الاتصال مع قاعدة البيانات"""
    
    def __init__(self, supabase, check_interval=300):
        self.supabase = supabase
        self.check_interval = check_interval
        self.last_check = 0
        self.is_healthy = True
        self.error_count = 0
        self.lock = Lock()
    
    def check_connection(self) -> bool:
        """فحص الاتصال بـ Supabase"""
        current_time = time.time()
        
        # فحص كل 5 دقائق فقط
        if current_time - self.last_check < self.check_interval:
            return self.is_healthy
        
        try:
            with self.lock:
                # محاولة استعلام بسيط
                response = self.supabase.table("users").select("count").limit(1).execute()
                self.is_healthy = True
                self.error_count = 0
                self.last_check = current_time
                return True
        except Exception as e:
            with self.lock:
                self.error_count += 1
                self.is_healthy = self.error_count < 3  # بعد 3 أخطاء، الاتصال معطل
                self.last_check = current_time
            return False
    
    def get_status(self) -> dict:
        """الحصول على حالة الاتصال"""
        return {
            "healthy": self.is_healthy,
            "error_count": self.error_count,
            "last_check": datetime.fromtimestamp(self.last_check).isoformat()
        }


# ═══════════════════════════════════════════════════════════════════
# 9️⃣ نظام معدل الطلبات (Rate Limiting)
# ═══════════════════════════════════════════════════════════════════

class RateLimiter:
    """التحكم في معدل الطلبات لمنع الإساءة"""
    
    def __init__(self, max_requests=10, window_seconds=60):
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.user_requests = defaultdict(list)
        self.lock = Lock()
    
    def is_allowed(self, user_id: int) -> Tuple[bool, Optional[int]]:
        """
        التحقق من السماح للمستخدم
        العودة: (مسموح/غير مسموح، عدد الطلبات المتبقية)
        """
        current_time = time.time()
        window_start = current_time - self.window_seconds
        
        with self.lock:
            # حذف الطلبات القديمة
            self.user_requests[user_id] = [
                t for t in self.user_requests[user_id] 
                if t > window_start
            ]
            
            if len(self.user_requests[user_id]) >= self.max_requests:
                return False, 0
            
            self.user_requests[user_id].append(current_time)
            remaining = self.max_requests - len(self.user_requests[user_id])
            
            return True, remaining
    
    def get_wait_time(self, user_id: int) -> int:
        """الحصول على وقت الانتظار قبل محاولة جديدة"""
        with self.lock:
            if user_id not in self.user_requests or not self.user_requests[user_id]:
                return 0
            
            oldest_request = min(self.user_requests[user_id])
            wait_seconds = int(oldest_request + self.window_seconds - time.time())
            return max(0, wait_seconds)


# ═══════════════════════════════════════════════════════════════════
# 🔟 نظام تخزين مؤقت للنتائج الثقيلة
# ═══════════════════════════════════════════════════════════════════

class ResultCache:
    """تخزين مؤقت للنتائج الثقيلة (تحليلات، رسوم بيانية)"""
    
    def __init__(self, ttl_seconds=1800):  # 30 دقيقة
        self.student_cache = {}  # {student_id: (data, timestamp)}
        self.ttl = ttl_seconds
        self.lock = Lock()
    
    def get_student_result(self, student_id: int) -> Optional[dict]:
        """جلب نتيجة الطالب من الـ cache"""
        with self.lock:
            if student_id not in self.student_cache:
                return None
            
            data, timestamp = self.student_cache[student_id]
            if time.time() - timestamp > self.ttl:
                del self.student_cache[student_id]
                return None
            
            return data
    
    def set_student_result(self, student_id: int, data: dict):
        """حفظ نتيجة الطالب في الـ cache"""
        with self.lock:
            self.student_cache[student_id] = (data, time.time())
    
    def invalidate(self, student_id: int = None):
        """مسح الـ cache (طالب معين أو الكل)"""
        with self.lock:
            if student_id:
                self.student_cache.pop(student_id, None)
            else:
                self.student_cache.clear()


# ═══════════════════════════════════════════════════════════════════
# 1️⃣1️⃣ Wrapper آمن لعمليات قاعدة البيانات مع Timeout
# ═══════════════════════════════════════════════════════════════════

class SafeDatabaseOperation:
    """تنفيذ آمن لعمليات قاعدة البيانات"""
    
    @staticmethod
    @retry_with_backoff(max_retries=3, initial_delay=0.5)
    def execute_with_timeout(operation, timeout=10):
        """
        تنفيذ عملية مع timeout
        مثال: SafeDatabaseOperation.execute_with_timeout(
                lambda: supabase.table('users').select('*').execute(),
                timeout=5
            )
        """
        try:
            # محاولة التنفيذ مع timeout
            result = operation()
            return result
        except TimeoutError:
            raise Exception("❌ انتهت مهلة الوقت لعملية قاعدة البيانات")
        except Exception as e:
            raise


# ═══════════════════════════════════════════════════════════════════
# 1️⃣2️⃣ نظام مراقبة الأداء والإحصائيات
# ═══════════════════════════════════════════════════════════════════

class PerformanceMonitor:
    """قياس ومراقبة أداء الدوال"""
    
    def __init__(self):
        self.metrics = defaultdict(lambda: {
            "calls": 0,
            "total_time": 0,
            "min_time": float('inf'),
            "max_time": 0,
            "errors": 0
        })
        self.lock = Lock()
    
    def measure(self, func_name: str):
        """ديكوريتور لقياس الأداء"""
        def decorator(func):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                start_time = time.time()
                try:
                    result = func(*args, **kwargs)
                    return result
                except Exception as e:
                    with self.lock:
                        self.metrics[func_name]["errors"] += 1
                    raise
                finally:
                    elapsed = time.time() - start_time
                    with self.lock:
                        metric = self.metrics[func_name]
                        metric["calls"] += 1
                        metric["total_time"] += elapsed
                        metric["min_time"] = min(metric["min_time"], elapsed)
                        metric["max_time"] = max(metric["max_time"], elapsed)
            
            return wrapper
        return decorator
    
    def get_report(self) -> dict:
        """تقرير شامل عن الأداء"""
        with self.lock:
            report = {}
            for func_name, metrics in self.metrics.items():
                avg_time = metrics["total_time"] / max(1, metrics["calls"])
                report[func_name] = {
                    "calls": metrics["calls"],
                    "avg_time_ms": round(avg_time * 1000, 2),
                    "min_time_ms": round(metrics["min_time"] * 1000, 2),
                    "max_time_ms": round(metrics["max_time"] * 1000, 2),
                    "errors": metrics["errors"],
                    "success_rate": round(
                        (metrics["calls"] - metrics["errors"]) / max(1, metrics["calls"]) * 100, 2
                    )
                }
            return report


# ═══════════════════════════════════════════════════════════════════
# آخر تحسينات سيتم تطبيقها في الملف الرئيسي
# ═══════════════════════════════════════════════════════════════════

# 1️⃣3️⃣ - API Response Time Monitoring
# 1️⃣4️⃣ - Async Database Operations
# 1️⃣5️⃣ - Query Result Compression
# 1️⃣6️⃣ - User Activity Tracking
# 1️⃣7️⃣ - Batch Processing for Large Operations
# 1️⃣8️⃣ - Graceful Degradation Mode
# 1️⃣9️⃣ - Circuit Breaker Pattern
# 2️⃣0️⃣ - Automated Health Checks & Healing

print("✅ تم تحميل مكتبة التحسينات - 12 وحدة جاهزة للاستخدام!")
