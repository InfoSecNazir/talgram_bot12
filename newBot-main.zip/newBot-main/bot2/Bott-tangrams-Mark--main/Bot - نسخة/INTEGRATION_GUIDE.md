# 🔧 دليل التكامل - البحث التفاعلي مع البوت الرئيسي

## 📌 خطوات التكامل السريعة

### 1️⃣ المكان الأول - استيراد وإعداد

في `final_bot_with_image.py` في **البداية** (بعد الاستيرادات العادية):

```python
# ==========================================
# الاستيرادات الأساسية الحالية
# ==========================================
import telebot
from telebot import types
import os
import json
from datetime import datetime
# ... واستيرادات أخرى موجودة ...

# ==========================================
# إضافة الاستيرادات للبحث التفاعلي ✨
# ==========================================
from supabase import create_client  # تأكد أنه موجود
from validators import InputValidator  # من improvements.py
```

---

### 2️⃣ المكان الثاني - قائمة الأوامر

ابحث عن دالة `setup_bot_commands()` وأضف فيها:

```python
def setup_bot_commands():
    """إعداد قائمة أوامر البوت"""
    user_commands = [
        BotCommand("start", "🏠 البدء والقائمة الرئيسية"),
        BotCommand("stats", "📊 الإحصائيات"),
        BotCommand("charts", "📈 الرسوم البيانية"),
        
        # ✨ أضف هذا السطر:
        BotCommand("search", "🔍 البحث عن طالب"),
        
        BotCommand("help", "❓ المساعدة"),
        # ... باقي الأوامر ...
    ]
    
    bot.set_my_commands(user_commands)
```

---

### 3️⃣ المكان الثالث - دالة البحث

أضف هذه الدالة الكاملة **قبل** `bot.infinity_polling()` بـ سطر واحد:

```python
# ==========================================
# 🔍 نظام البحث التفاعلي
# ==========================================

@bot.message_handler(commands=['search'])
def handle_search_command(message):
    """معالج أمر البحث /search"""
    user_id = message.from_user.id
    username = message.from_user.first_name or "مستخدم"
    
    # التحقق من النص
    search_text = message.text.replace('/search', '').strip()
    
    if not search_text:
        msg = bot.send_message(
            user_id,
            "🔍 <b>البحث عن الطالب</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "من فضلك أدخل اسم الطالب أو رقم الجلوس:\n\n"
            "<i>مثال: /search أحمد</i>",
            parse_mode='HTML'
        )
        return
    
    # Validate input
    if len(search_text) < 2:
        bot.send_message(user_id, "❌ يجب أن يكون البحث حرفين على الأقل")
        return
    
    # إرسال مؤشر الكتابة
    bot.send_chat_action(user_id, 'typing')
    
    try:
        # البحث في قاعدة البيانات
        response = supabase.table('students').select('*').ilike('name', f'%{search_text}%').limit(15).execute()
        results = response.data if response.data else []
        
    except Exception as e:
        logging.error(f"❌ خطأ في البحث: {e}")
        bot.send_message(
            user_id,
            f"❌ حدث خطأ في البحث\n"
            f"<i>الخطأ: {str(e)[:100]}</i>",
            parse_mode='HTML'
        )
        return
    
    # إذا لم يجد نتائج
    if not results:
        bot.send_message(
            user_id,
            f"❌ <b>لم يتم العثور على نتائج</b>\n"
            f"البحث عن: <code>{search_text}</code>",
            parse_mode='HTML'
        )
        return
    
    # إنشاء لوحة المفاتيح بالنتائج
    keyboard = types.InlineKeyboardMarkup(row_width=1)
    buttons = []
    
    for i, student in enumerate(results):
        name = student.get('name', 'Unknown')[:25]  # حد أقصى 25 حرف
        student_id = student.get('student_id', 'N/A')
        btn_text = f"👤 {name} ({student_id})"
        
        button = types.InlineKeyboardButton(
            text=btn_text,
            callback_data=f"view_student_{student['id']}"
        )
        buttons.append(button)
    
    keyboard.add(*buttons)
    
    # إرسال النتائج
    search_result_msg = bot.send_message(
        user_id,
        f"🔎 <b>نتائج البحث</b>\n"
        f"━━━━━━━━━━━━━━━\n"
        f"📌 عن: <code>{search_text}</code>\n"
        f"📊 عدد النتائج: <b>{len(results)}</b>\n\n"
        f"<i>اختر الطالب من القائمة:</i>",
        reply_markup=keyboard,
        parse_mode='HTML'
    )
    
    # حفظ معرف الرسالة (للحذف لاحقاً)
    if not hasattr(bot, 'search_messages'):
        bot.search_messages = {}
    
    bot.search_messages[user_id] = search_result_msg.message_id
    
    # تسجيل البحث
    try:
        logging.info(f"🔍 بحث من {username}: '{search_text}' - {len(results)} نتائج")
    except:
        pass


@bot.callback_query_handler(func=lambda call: call.data.startswith('view_student_'))
def handle_student_view(call):
    """معالج اختيار الطالب من قائمة البحث"""
    user_id = call.from_user.id
    message_id = call.message.message_id
    
    # استخراج ID الطالب
    try:
        student_id = int(call.data.replace('view_student_', ''))
    except:
        bot.answer_callback_query(call.id, "❌ خطأ في البيانات", show_alert=True)
        return
    
    # حذف رسالة البحث (قائمة الأزرار)
    try:
        bot.delete_message(user_id, message_id)
    except Exception as e:
        logging.warning(f"⚠️ لم يتمكن من حذف الرسالة: {e}")
    
    # جلب بيانات الطالب الكاملة
    try:
        bot.send_chat_action(user_id, 'typing')
        response = supabase.table('students').select('*').eq('id', student_id).execute()
        
        if not response.data:
            bot.send_message(user_id, "❌ لم يتم العثور على بيانات الطالب")
            return
        
        student = response.data[0]
        
    except Exception as e:
        logging.error(f"❌ خطأ في جلب بيانات الطالب: {e}")
        bot.send_message(user_id, f"❌ خطأ في جلب البيانات: {str(e)[:50]}")
        return
    
    # بناء رسالة النتيجة
    result_text = f"""
<b>📊 بيانات الطالب</b>
━━━━━━━━━━━━━━━━━━━
👤 <b>الاسم:</b> {student.get('name', 'N/A')}
🆔 <b>رقم الجلوس:</b> <code>{student.get('student_id', 'N/A')}</code>
📚 <b>القسم:</b> {student.get('department', 'N/A')}
⭐ <b>المعدل:</b> {student.get('gpa', 'N/A')}
📅 <b>المستوى:</b> {student.get('level', 'N/A')}
"""
    
    # الأزرار
    result_keyboard = types.InlineKeyboardMarkup()
    
    result_keyboard.add(
        types.InlineKeyboardButton("📊 إحصائيات", callback_data=f"student_stats_{student_id}"),
        types.InlineKeyboardButton("📈 رسوم", callback_data=f"student_charts_{student_id}")
    )
    
    result_keyboard.add(
        types.InlineKeyboardButton("🔄 بحث جديد", callback_data=f"search_again")
    )
    
    # إرسال النتيجة
    bot.send_message(
        user_id,
        result_text,
        reply_markup=result_keyboard,
        parse_mode='HTML'
    )
    
    # الرد على الزر المضغوط
    bot.answer_callback_query(call.id, "✅ تم اختيار الطالب", show_alert=False)


@bot.callback_query_handler(func=lambda call: call.data == 'search_again')
def handle_search_again(call):
    """زر البحث الجديد"""
    user_id = call.from_user.id
    bot.send_message(
        user_id,
        "🔍 أدخل اسم الطالب:\n"
        "/search اسم الطالب",
        parse_mode='HTML'
    )


# ==========================================
# نهاية نظام البحث التفاعلي
# ==========================================
```

---

### 4️⃣ المكان الرابع - معالج البحث من الرسالة

إذا أردت السماح بالبحث من أي رسالة (مثل "/search" بدون أمر مسجل):

```python
@bot.message_handler(func=lambda message: message.text.startswith('/search'))
def handle_search_from_message(message):
    """السماح بالبحث من أي رسالة"""
    handle_search_command(message)
```

---

## 🎯 النقاط الهامة

### تأكد من أن لديك:

```python
# 1. مكتبة Telebot
import telebot
from telebot import types

# 2. Supabase client
from supabase import create_client
supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

# 3. جدول students في قاعدة البيانات مع الأعمدة:
# - id (primary key)
# - name
# - student_id
# - department
# - gpa
# - level
```

---

## 🧪 الاختبار

```bash
# في البوت:
/search أحمد
# يجب أن يظهر قائمة بالطلاب

# الضغط على اسم:
# يجب أن تختفي القائمة وتظهر البيانات الكاملة
```

---

## 🔧 التخصيصات

### تغيير عدد النتائج:
```python
# الحالي:
.limit(15).execute()

# الجديد (مثال 10):
.limit(10).execute()
```

### إضافة مرشح إضافي:
```python
# البحث فقط في قسم معين
response = supabase.table('students') \
    .select('*') \
    .ilike('name', f'%{search_text}%') \
    .eq('department', 'الفيزياء') \
    .limit(15) \
    .execute()
```

### تغيير الـ emoji:
```python
# حالي:
f"👤 {name} ({student_id})"

# جديد:
f"🎓 {name} [ID: {student_id}]"
```

---

## ✅ قائمة التحقق النهائية

- [ ] نسخت جميع الدوال
- [ ] أضفت /search إلى قائمة الأوامر
- [ ] تأكدت من وجود جدول students
- [ ] تأكدت من وجود supabase client
- [ ] اختبرت البحث
- [ ] تأكدت من حذف قائمة الأزرار
- [ ] تأكدت من إرسال البيانات

---

## 🚀 النتيجة النهائية

```
المستخدم: /search أحمد
        ↓
البوت: 🔎 نتائج البحث
       عن: أحمد
       عدد النتائج: 3
       
       👤 أحمد محمود (12345)
       👤 أحمد علي (12346)
       👤 أحمد حسن (12347)

المستخدم: اضغط على "أحمد محمود"
        ↓
🗑️ البوت: حذف القائمة
        ↓
📨 البوت: 📊 بيانات الطالب
         👤 الاسم: أحمد محمود
         🆔 رقم الجلوس: 12345
         📚 القسم: الفيزياء
         ⭐ المعدل: 3.85
         
         [📊 إحصائيات] [📈 رسوم]
         [🔄 بحث جديد]
```

## 💡 ملاحظات مهمة

1. **حذف الأزرار تلقائياً**: يتم حذف رسالة الأزرار عند اختيار طالب
2. **رسالة انتظار**: يتم إرسال مؤشر الكتابة للمستخدم أثناء البحث
3. **معالجة الأخطاء**: معالج الأخطاء يحفظ المستخدم من الانهيارات
4. **تسجيل العمليات**: يتم تسجيل كل بحث في السجلات (logging)
5. **الأمان**: التحقق من صحة البيانات قبل الاستخدام

**كل شيء جاهز الآن!** 🎉
