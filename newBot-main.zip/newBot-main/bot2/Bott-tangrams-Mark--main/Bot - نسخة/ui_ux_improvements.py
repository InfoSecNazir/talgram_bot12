# -*- coding: utf-8 -*-
"""
🎨 تحسينات التصميم والتفاعل (UI/UX Improvements)
نظام شامل لتحسين تجربة المستخدم والواجهة البصرية
"""

# ═════════════════════════════════════════════════════════════════════════════════
# 1️⃣ نظام الألوان والـ Emoji الذكي
# ═════════════════════════════════════════════════════════════════════════════════

class ColorAndEmojiSystem:
    """نظام الألوان والـ emoji المتناسق"""
    
    # ألوان HTML للرسائل
    COLORS = {
        'success': '#2ecc71',      # أخضر
        'error': '#e74c3c',        # أحمر
        'warning': '#f39c12',      # برتقالي
        'info': '#3498db',         # أزرق
        'primary': '#9b59b6',      # بنفسجي
        'secondary': '#1abc9c',    # فيروزي
        'dark': '#2c3e50',         # رمادي غامق
        'light': '#ecf0f1'         # رمادي فاتح
    }
    
    # Emoji النسق المتناسق
    EMOJI = {
        # الحالات
        'success': '✅',
        'error': '❌',
        'warning': '⚠️',
        'info': 'ℹ️',
        'thinking': '⏳',
        'refresh': '🔄',
        'settings': '⚙️',
        'search': '🔍',
        'chart': '📊',
        'stats': '📈',
        'user': '👤',
        'users': '👥',
        'home': '🏠',
        'back': '🔙',
        
        # الأرقام والهرمية
        'first': '🥇',
        'second': '🥈',
        'third': '🥉',
        'top': '⭐',
        'hot': '🔥',
        'new': '🆕',
        'featured': '✨',
        
        # الإجراءات
        'edit': '✏️',
        'delete': '🗑️',
        'add': '➕',
        'next': '▶️',
        'previous': '◀️',
        'save': '💾',
        'upload': '📤',
        'download': '📥',
        
        # الفئات
        'physics': '⚛️',
        'math': '🔢',
        'chemistry': '🧪',
        'biology': '🧬',
        'english': '🇬🇧',
        'arabic': '🇸🇦',
        'history': '📜',
        'geography': '🗺️',
        'sports': '⚽',
        'art': '🎨',
        
        # الحالات الخاصة
        'banned': '🚫',
        'verified': '✔️',
        'crown': '👑',
        'lightning': '⚡',
        'rocket': '🚀',
        'thumbs_up': '👍',
        'thumbs_down': '👎',
    }
    
    @staticmethod
    def colorize_text(text: str, color: str = 'info') -> str:
        """تلوين النص برسالة HTML"""
        color_code = ColorAndEmojiSystem.COLORS.get(color, ColorAndEmojiSystem.COLORS['info'])
        return f"<code style='color: {color_code}'>{text}</code>"
    
    @staticmethod
    def get_emoji(key: str, default: str = '•') -> str:
        """الحصول على emoji مناسب"""
        return ColorAndEmojiSystem.EMOJI.get(key, default)
    
    @staticmethod
    def format_header(title: str, emoji_key: str = 'info') -> str:
        """تنسيق رأس الرسالة"""
        emoji = ColorAndEmojiSystem.get_emoji(emoji_key)
        return f"\n<b>{emoji} {title}</b>\n━━━━━━━━━━━━━━━━━━━━\n"
    
    @staticmethod
    def format_section(content: str, title: str = None, emoji_key: str = None) -> str:
        """تنسيق قسم من الرسالة"""
        if title:
            emoji = ColorAndEmojiSystem.get_emoji(emoji_key or 'info')
            return f"\n<b>{emoji} {title}</b>\n{content}\n"
        return f"\n{content}\n"


# ═════════════════════════════════════════════════════════════════════════════════
# 2️⃣ مولد الرسائل الذكي (Smart Message Generator)
# ═════════════════════════════════════════════════════════════════════════════════

class SmartMessageGenerator:
    """إنشاء رسائل ديناميكية وجذابة"""
    
    # قوالب الرسائل
    TEMPLATES = {
        'welcome': "🎉 أهلاً بك {name}!\nأنا هنا لمساعدتك في الوصول للمعلومات بسهولة",
        'search_result': "🔎 وجدت {count} نتيجة عن '{query}'",
        'no_results': "😔 للأسف، لم أجد نتائج عن '{query}'",
        'loading': "⏳ جاري البحث عن '{query}'...",
        'error_generic': "❌ حدث خطأ ما. يرجى المحاولة لاحقاً",
        'success': "✅ تم بنجاح!",
        'info': "ℹ️ معلومة مهمة: {message}",
        'tip': "💡 نصيحة: {message}",
    }
    
    @staticmethod
    def get_greeting_message(user_first_name: str, hour: int = None) -> str:
        """رسالة ترحيب بناءً على الوقت"""
        import datetime
        
        if hour is None:
            hour = datetime.datetime.now().hour
        
        if hour < 12:
            greeting = "🌅 صباح الخير"
        elif hour < 17:
            greeting = "☀️ تحية الظهيرة"
        elif hour < 20:
            greeting = "🌆 مساء الخير"
        else:
            greeting = "🌙 تصبح على خير"
        
        return f"{greeting} {user_first_name} 👋"
    
    @staticmethod
    def format_student_card(student_data: dict, include_rank: bool = False) -> str:
        """عرض بطاقة الطالب الجميلة"""
        emoji = ColorAndEmojiSystem.get_emoji
        
        card = f"""
<b>📋 بيانات الطالب</b>
━━━━━━━━━━━━━━━━━━━━
{emoji('user')} <b>الاسم:</b> {student_data.get('name', 'N/A')}
🆔 <b>رقم الجلوس:</b> <code>{student_data.get('student_id', 'N/A')}</code>
📚 <b>القسم:</b> {student_data.get('department', 'N/A')}
⭐ <b>المعدل:</b> {student_data.get('gpa', 'N/A')}
📊 <b>المستوى:</b> {student_data.get('level', 'N/A')}
"""
        
        if include_rank and student_data.get('rank'):
            rank = student_data.get('rank')
            
            if rank == 1:
                rank_emoji = emoji('first')
            elif rank == 2:
                rank_emoji = emoji('second')
            elif rank == 3:
                rank_emoji = emoji('third')
            else:
                rank_emoji = '🏅'
            
            card += f"\n{rank_emoji} <b>الترتيب:</b> {rank}"
        
        return card.strip()
    
    @staticmethod
    def format_statistics_card(stats: dict) -> str:
        """عرض بطاقة الإحصائيات"""
        emoji = ColorAndEmojiSystem.get_emoji
        
        card = f"""
<b>📊 الإحصائيات</b>
━━━━━━━━━━━━━━━━━━━━
📈 <b>إجمالي الطلاب:</b> {stats.get('total_students', 0)}
⭐ <b>متوسط المعدل:</b> {stats.get('avg_gpa', 0):.2f}
{emoji('first')} <b>أعلى معدل:</b> {stats.get('max_gpa', 0):.2f}
📉 <b>أقل معدل:</b> {stats.get('min_gpa', 0):.2f}
👥 <b>عدد الزوار:</b> {stats.get('visitors_count', 0)}
"""
        return card.strip()
    
    @staticmethod
    def format_top_students_list(students: list, limit: int = 5) -> str:
        """عرض قائمة الطلاب المتفوقين"""
        emoji = ColorAndEmojiSystem.get_emoji
        
        message = f"\n<b>⭐ أفضل {min(limit, len(students))} طلاب</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        
        for idx, student in enumerate(students[:limit], 1):
            if idx == 1:
                rank_emoji = emoji('first')
            elif idx == 2:
                rank_emoji = emoji('second')
            elif idx == 3:
                rank_emoji = emoji('third')
            else:
                rank_emoji = f"#{idx}"
            
            name = student.get('name', 'Unknown')[:20]
            gpa = student.get('gpa', 'N/A')
            
            message += f"{rank_emoji} <b>{name}</b> - ⭐ {gpa}\n"
        
        return message.strip()
    
    @staticmethod
    def create_progress_bar(current: float, total: float, bar_length: int = 20) -> str:
        """إنشاء شريط تقدم"""
        percentage = (current / total) * 100 if total > 0 else 0
        filled_length = int(bar_length * current // total)
        
        bar = '█' * filled_length + '░' * (bar_length - filled_length)
        
        return f"[{bar}] {percentage:.0f}%"


# ═════════════════════════════════════════════════════════════════════════════════
# 3️⃣ نظام الأزرار الذكي (Smart Button System)
# ═════════════════════════════════════════════════════════════════════════════════

class SmartButtonGenerator:
    """إنشاء أزرار تفاعلية بذكاء"""
    
    @staticmethod
    def create_action_buttons(actions: list) -> 'types.InlineKeyboardMarkup':
        """إنشاء أزرار الإجراءات"""
        from telebot import types
        
        keyboard = types.InlineKeyboardMarkup()
        emoji = ColorAndEmojiSystem.get_emoji
        
        for action in actions:
            button_text = f"{emoji(action.get('emoji_key', 'info'))} {action['label']}"
            button = types.InlineKeyboardButton(
                text=button_text,
                callback_data=action['callback_data']
            )
            keyboard.add(button)
        
        return keyboard
    
    @staticmethod
    def create_pagination_buttons(current_page: int, total_pages: int, 
                                  callback_prefix: str = 'page') -> 'types.InlineKeyboardMarkup':
        """إنشاء أزرار التصفح"""
        from telebot import types
        
        keyboard = types.InlineKeyboardMarkup()
        
        # السابق
        if current_page > 1:
            prev_btn = types.InlineKeyboardButton(
                text="◀️ السابق",
                callback_data=f"{callback_prefix}_{current_page - 1}"
            )
            keyboard.add(prev_btn)
        
        # الرقم الحالي
        info_text = f"📄 {current_page}/{total_pages}"
        
        # التالي
        if current_page < total_pages:
            next_btn = types.InlineKeyboardButton(
                text="التالي ▶️",
                callback_data=f"{callback_prefix}_{current_page + 1}"
            )
            
            if current_page > 1:
                keyboard.add(prev_btn, next_btn)
            else:
                keyboard.add(next_btn)
        
        keyboard.add(types.InlineKeyboardButton(text=info_text, callback_data="nope"))
        
        return keyboard
    
    @staticmethod
    def create_quick_actions_menu() -> 'types.InlineKeyboardMarkup':
        """قائمة الإجراءات السريعة"""
        from telebot import types
        
        emoji = ColorAndEmojiSystem.get_emoji
        
        keyboard = types.InlineKeyboardMarkup()
        
        quick_actions = [
            (f"{emoji('search')} بحث", "action_search"),
            (f"{emoji('stats')} إحصائيات", "action_stats"),
            (f"{emoji('chart')} رسوم بيانية", "action_charts"),
        ]
        
        row = []
        for label, callback in quick_actions:
            row.append(types.InlineKeyboardButton(text=label, callback_data=callback))
        
        keyboard.row(*row)
        
        return keyboard


# ═════════════════════════════════════════════════════════════════════════════════
# 4️⃣ نظام المؤشرات البصرية (Visual Feedback System)
# ═════════════════════════════════════════════════════════════════════════════════

class VisualFeedbackSystem:
    """نظام أشرطة التقدم والمؤشرات البصرية"""
    
    @staticmethod
    def show_loading_animation(bot, chat_id: int, message_text: str, duration: int = 5):
        """عرض رسالة تحميل متحركة"""
        import time
        
        frames = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
        
        message = bot.send_message(chat_id, f"{frames[0]} {message_text}")
        
        start_time = time.time()
        frame_idx = 0
        
        while time.time() - start_time < duration:
            try:
                bot.edit_message_text(
                    f"{frames[frame_idx % len(frames)]} {message_text}",
                    chat_id,
                    message.message_id
                )
            except:
                pass
            
            frame_idx += 1
            time.sleep(0.3)
        
        return message
    
    @staticmethod
    def create_status_indicator(status: str) -> str:
        """مؤشر الحالة"""
        indicators = {
            'online': '🟢 متصل',
            'offline': '🔴 غير متصل',
            'busy': '🟡 مشغول',
            'idle': '⚪ غير نشط',
            'dnd': '🔴 لا تزعج',
        }
        
        return indicators.get(status, '⚪ غير معروف')
    
    @staticmethod
    def create_rating_bar(rating: float, max_rating: float = 5.0) -> str:
        """شريط التقييم"""
        filled_stars = int(rating)
        empty_stars = int(max_rating - rating)
        
        bar = '⭐' * filled_stars + '☆' * empty_stars
        
        return f"{bar} {rating:.1f}/{max_rating}"
    
    @staticmethod
    def create_activity_indicator(activity_level: int) -> str:
        """مؤشر النشاط (1-5)"""
        level = min(max(activity_level, 1), 5)
        
        indicators = {
            1: '▁ منخفض جداً',
            2: '▂▂ منخفض',
            3: '▃▃▃ متوسط',
            4: '▄▄▄▄ عالي',
            5: '▅▅▅▅▅ عالي جداً',
        }
        
        return indicators.get(level, 'غير معروف')


# ═════════════════════════════════════════════════════════════════════════════════
# 5️⃣ نظام الإخطارات الذكية (Smart Notifications)
# ═════════════════════════════════════════════════════════════════════════════════

class SmartNotificationSystem:
    """نظام الإخطارات والتنبيهات"""
    
    NOTIFICATION_TYPES = {
        'info': {'emoji': 'ℹ️', 'color': 'info', 'sound': False},
        'success': {'emoji': '✅', 'color': 'success', 'sound': False},
        'warning': {'emoji': '⚠️', 'color': 'warning', 'sound': True},
        'error': {'emoji': '❌', 'color': 'error', 'sound': True},
        'milestone': {'emoji': '🎉', 'color': 'primary', 'sound': True},
        'achievement': {'emoji': '🏆', 'color': 'primary', 'sound': True},
    }
    
    @staticmethod
    def create_notification(notification_type: str, title: str, message: str, 
                           action_buttons: list = None) -> str:
        """إنشاء إخطار"""
        notif_config = SmartNotificationSystem.NOTIFICATION_TYPES.get(
            notification_type, 
            SmartNotificationSystem.NOTIFICATION_TYPES['info']
        )
        
        emoji = notif_config['emoji']
        
        notification = f"""
{emoji} <b>{title}</b>
━━━━━━━━━━━━━━━━━━━━
{message}
"""
        
        return notification.strip()
    
    @staticmethod
    def create_milestone_notification(milestone: str, description: str) -> str:
        """إخطار الإنجازات"""
        milestones = {
            'first_search': ('🔍 أول بحث', 'مبروك! لقد أتممت أول بحث'),
            'ten_searches': ('🔍 عشر عمليات بحث', 'ممتاز! لقد وصلت إلى 10 عمليات بحث'),
            'hundred_searches': ('🔍 مائة بحث', 'رائع! لقد وصلت إلى 100 بحث'),
            'top_student': ('⭐ طالب متفوق', 'مبروك! أنت من أفضل الطلاب'),
            'perfect_gpa': ('🏆 معدل كامل', 'تهانينا! حققت معدلاً كاملاً'),
        }
        
        if milestone in milestones:
            emoji, title = milestones[milestone]
            return f"\n{emoji} <b>{title}</b>\n📝 {description}\n🎉 تهانينا!\n"
        
        return f"\n🎉 <b>{milestone}</b>\n📝 {description}\n"
    
    @staticmethod
    def create_error_recovery_message(error_type: str) -> str:
        """رسائل التعافي من الأخطاء الودية"""
        recovery_messages = {
            'connection_error': "🔌 يبدو أن الاتصال مقطوع. جاري إعادة المحاولة...",
            'timeout': "⏰ استغرق الطلب وقتاً أطول من المتوقع. دعني أحاول مرة أخرى...",
            'not_found': "🔍 عذراً، لم أتمكن من العثور على المعلومات المطلوبة.",
            'permission_denied': "🔒 ليس لديك الصلاحيات اللازمة للقيام بهذا الإجراء.",
            'rate_limited': "⏱️ جاري الانتظار قليلاً قبل المحاولة مرة أخرى...",
        }
        
        return recovery_messages.get(error_type, "❌ حدث خطأ ما. يرجى المحاولة لاحقاً.")


# ═════════════════════════════════════════════════════════════════════════════════
# 6️⃣ نظام السياق والشخصنة (Context & Personalization)
# ═════════════════════════════════════════════════════════════════════════════════

class PersonalizationSystem:
    """نظام تخصيص الرسائل والواجهة"""
    
    def __init__(self):
        self.user_preferences = {}
        self.user_conversation_history = {}
    
    def get_personalized_greeting(self, user_id: int, user_data: dict) -> str:
        """تحية مخصصة بناءً على تاريخ المستخدم"""
        import datetime
        
        visit_count = user_data.get('visit_count', 0)
        last_visit = user_data.get('last_visit', None)
        
        hour = datetime.datetime.now().hour
        
        # حسب عدد الزيارات
        if visit_count == 1:
            frequency_msg = "أول مرة تزور البوت!"
        elif visit_count < 5:
            frequency_msg = f"زائر جديد نسبياً ({visit_count} زيارات)"
        elif visit_count < 20:
            frequency_msg = f"زائر معتاد ({visit_count} زيارة)"
        else:
            frequency_msg = f"صديق قديم! ({visit_count} زيارة)"
        
        # حسب الوقت
        if hour < 12:
            time_msg = "🌅 صباح الخير"
        elif hour < 17:
            time_msg = "☀️ تحية الظهيرة"
        else:
            time_msg = "🌙 مساء الخير"
        
        return f"{time_msg}\n{frequency_msg}"
    
    def get_context_aware_response(self, user_id: int, context: str) -> str:
        """رد بناءً على السياق"""
        # يمكن تخزين السياق السابق للمستخدم
        if user_id not in self.user_conversation_history:
            self.user_conversation_history[user_id] = []
        
        self.user_conversation_history[user_id].append(context)
        
        # الاحتفاظ بآخر 10 سياقات فقط
        if len(self.user_conversation_history[user_id]) > 10:
            self.user_conversation_history[user_id] = \
                self.user_conversation_history[user_id][-10:]
        
        return context
    
    def should_show_help_tip(self, user_id: int, feature: str) -> bool:
        """هل يجب عرض نصيحة المساعدة؟"""
        if user_id not in self.user_preferences:
            self.user_preferences[user_id] = {
                'help_tips_shown': {},
                'preferences': {}
            }
        
        shown_count = self.user_preferences[user_id]['help_tips_shown'].get(feature, 0)
        
        # عرض النصيحة أول 3 مرات فقط
        return shown_count < 3
    
    def mark_help_tip_shown(self, user_id: int, feature: str):
        """تعليم النصيحة كمرئية"""
        if user_id not in self.user_preferences:
            self.user_preferences[user_id] = {
                'help_tips_shown': {},
                'preferences': {}
            }
        
        current_count = self.user_preferences[user_id]['help_tips_shown'].get(feature, 0)
        self.user_preferences[user_id]['help_tips_shown'][feature] = current_count + 1


# ═════════════════════════════════════════════════════════════════════════════════
# 7️⃣ نظام التصميم المتجاوب (Responsive Design)
# ═════════════════════════════════════════════════════════════════════════════════

class ResponsiveDesignSystem:
    """تعديل الواجهة حسب حجم الشاشة والجهاز"""
    
    @staticmethod
    def adapt_message_for_device(message: str, device_type: str = 'mobile') -> str:
        """تعديل الرسالة حسب نوع الجهاز"""
        if device_type == 'mobile':
            # تقليل الخطوط الطويلة
            lines = message.split('\n')
            adapted_lines = [
                line[:60] + '...' if len(line) > 60 else line
                for line in lines
            ]
            return '\n'.join(adapted_lines)
        
        return message
    
    @staticmethod
    def get_optimal_button_count(device_type: str = 'mobile') -> int:
        """العدد الأمثل للأزرار حسب الجهاز"""
        if device_type == 'mobile':
            return 2  # أزراران جنباً إلى جنب
        elif device_type == 'tablet':
            return 3
        else:  # desktop
            return 4
    
    @staticmethod
    def format_for_screen_size(content: str, max_width: int = 60) -> str:
        """تنسيق المحتوى لعرض معين"""
        lines = content.split('\n')
        formatted_lines = []
        
        for line in lines:
            if len(line) > max_width:
                # كسر الخط الطويل
                words = line.split(' ')
                current_line = ''
                
                for word in words:
                    if len(current_line) + len(word) + 1 <= max_width:
                        current_line += word + ' '
                    else:
                        if current_line:
                            formatted_lines.append(current_line.strip())
                        current_line = word + ' '
                
                if current_line:
                    formatted_lines.append(current_line.strip())
            else:
                formatted_lines.append(line)
        
        return '\n'.join(formatted_lines)


# ═════════════════════════════════════════════════════════════════════════════════
# 8️⃣ نظام الرسوم الديناميكية (Dynamic Charts)
# ═════════════════════════════════════════════════════════════════════════════════

class DynamicChartsGenerator:
    """إنشاء رسوم بيانية نصية"""
    
    @staticmethod
    def create_bar_chart(data: dict, max_bar_length: int = 20, title: str = None) -> str:
        """إنشاء مخطط أعمدة"""
        if not data:
            return "لا توجد بيانات"
        
        max_value = max(data.values())
        chart = ""
        
        if title:
            chart += f"📊 <b>{title}</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        
        for label, value in data.items():
            percentage = (value / max_value * 100) if max_value > 0 else 0
            bar_length = int((value / max_value) * max_bar_length)
            bar = '█' * bar_length + '░' * (max_bar_length - bar_length)
            chart += f"{label:15} {bar} {percentage:.0f}%\n"
        
        return chart
    
    @staticmethod
    def create_pie_chart_text(data: dict, title: str = None) -> str:
        """إنشاء مخطط دائري نصي"""
        if not data:
            return "لا توجد بيانات"
        
        total = sum(data.values())
        chart = ""
        
        if title:
            chart += f"🥧 <b>{title}</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        
        for label, value in data.items():
            percentage = (value / total * 100) if total > 0 else 0
            segments = int(percentage / 5)
            pie = '●' * segments
            chart += f"{label:15} {pie:20} {percentage:.1f}%\n"
        
        return chart
    
    @staticmethod
    def create_trend_chart(values: list, title: str = None) -> str:
        """إنشاء مخطط اتجاهات"""
        if not values or len(values) < 2:
            return "لا توجد بيانات كافية"
        
        min_val = min(values)
        max_val = max(values)
        range_val = max_val - min_val if max_val > min_val else 1
        
        chart = ""
        if title:
            chart += f"📈 <b>{title}</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        
        for idx, value in enumerate(values):
            height = int(((value - min_val) / range_val) * 10) if range_val > 0 else 0
            bar = '▁▂▃▄▅▆▇█'[min(height, 7)]
            chart += f"{idx+1:2} {bar} {value:.2f}\n"
        
        return chart


# ═════════════════════════════════════════════════════════════════════════════════
# 💫 مثال الاستخدام
# ═════════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    # اختبار نظام الألوان والـ Emoji
    print("=" * 50)
    print("🎨 اختبار نظام الألوان والـ Emoji")
    print("=" * 50)
    
    header = ColorAndEmojiSystem.format_header("اختبار البحث", "search")
    print(header)
    
    # اختبار مولد الرسائل
    print("\n" + "=" * 50)
    print("💬 اختبار مولد الرسائل")
    print("=" * 50)
    
    greeting = SmartMessageGenerator.get_greeting_message("أحمد")
    print(greeting)
    
    # اختبار بطاقة الطالب
    print("\n" + "=" * 50)
    print("👤 اختبار بطاقة الطالب")
    print("=" * 50)
    
    student = {
        'name': 'أحمد محمود',
        'student_id': '12345',
        'department': 'الفيزياء',
        'gpa': '3.85',
        'level': '3',
        'rank': 1
    }
    
    card = SmartMessageGenerator.format_student_card(student, include_rank=True)
    print(card)
    
    # اختبار شريط التقدم
    print("\n" + "=" * 50)
    print("⏳ اختبار شريط التقدم")
    print("=" * 50)
    
    progress = SmartMessageGenerator.create_progress_bar(7, 10)
    print(f"التقدم: {progress}")
    
    # اختبار المخطط
    print("\n" + "=" * 50)
    print("📊 اختبار المخطط")
    print("=" * 50)
    
    data = {
        'الفيزياء': 85,
        'الرياضيات': 92,
        'الكيمياء': 78,
        'الإنجليزية': 88,
    }
    
    chart = DynamicChartsGenerator.create_bar_chart(data, title="درجات الطلاب")
    print(chart)
    
    print("\n✅ اكتملت الاختبارات!")
