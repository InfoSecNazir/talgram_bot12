# -*- coding: utf-8 -*-
"""
🔍 نظام البحث التفاعلي عن الطالب
عند الضغط على النتيجة → حذف القائمة + إرسال النتيجة
"""

import telebot
from telebot import types

# ═══════════════════════════════════════════════════════════════════════════════
# 1️⃣ أمر البحث - عرض قائمة بالنتائج
# ═══════════════════════════════════════════════════════════════════════════════

@bot.message_handler(commands=['search'])
def handle_search(message):
    """البحث عن الطالب - عرض النتائج كأزرار"""
    user_id = message.from_user.id
    
    # استخراج الكلمة المبحوث عنها
    text = message.text.replace('/search', '').strip()
    
    if not text or len(text) < 2:
        bot.send_message(user_id, "❌ أدخل اسم الطالب (حرفين على الأقل)")
        return
    
    # البحث في قاعدة البيانات
    try:
        response = supabase.table('students').select('*').ilike('name', f'%{text}%').execute()
        results = response.data or []
        
    except Exception as e:
        error_handler.handle("فشل البحث", exception=e, user_id=user_id)
        bot.send_message(user_id, "❌ حدث خطأ في البحث")
        return
    
    # لم يتم العثور على نتائج
    if not results:
        bot.send_message(user_id, f"❌ لم يتم العثور على طالب باسم '{text}'")
        return
    
    # عرض النتائج كأزرار
    keyboard = types.InlineKeyboardMarkup()
    
    for student in results[:15]:  # أقصى 15 نتيجة
        btn_text = f"{student['name']} ({student.get('student_id', 'N/A')})"
        btn_callback = f"select_student_{student['id']}"
        
        keyboard.add(
            types.InlineKeyboardButton(
                text=btn_text,
                callback_data=btn_callback
            )
        )
    
    # رسالة البحث
    search_msg = bot.send_message(
        user_id,
        f"🔍 <b>نتائج البحث</b> عن '{text}'\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"عدد النتائج: {len(results)}\n\n"
        f"اختر الطالب المطلوب:",
        reply_markup=keyboard,
        parse_mode='HTML'
    )
    
    # حفظ message_id لحذفه لاحقاً
    # (يمكن استخدام قاموس لتخزين بيانات المستخدم)
    if not hasattr(bot, 'search_messages'):
        bot.search_messages = {}
    
    bot.search_messages[user_id] = search_msg.message_id


# ═══════════════════════════════════════════════════════════════════════════════
# 2️⃣ معالج الضغط على النتيجة
# ═══════════════════════════════════════════════════════════════════════════════

@bot.callback_query_handler(func=lambda call: call.data.startswith('select_student_'))
def handle_student_selection(call):
    """معالج الضغط على الطالب"""
    user_id = call.from_user.id
    message_id = call.message.message_id
    
    # استخراج ID الطالب
    student_id = int(call.data.replace('select_student_', ''))
    
    # 1️⃣ حذف قائمة الأزرار (الرسالة السابقة)
    try:
        bot.delete_message(user_id, message_id)
    except Exception as e:
        print(f"⚠️ لم يتمكن من حذف الرسالة: {e}")
    
    # 2️⃣ جلب بيانات الطالب
    try:
        response = supabase.table('students').select('*').eq('id', student_id).execute()
        
        if not response.data:
            bot.send_message(user_id, "❌ لم يتم العثور على بيانات الطالب")
            return
        
        student_data = response.data[0]
        
    except Exception as e:
        error_handler.handle("فشل جلب بيانات الطالب", exception=e, user_id=user_id)
        bot.send_message(user_id, "❌ حدث خطأ في جلب البيانات")
        return
    
    # 3️⃣ إرسال النتيجة النهائية
    send_student_result(user_id, student_data)
    
    # إخفاء الرد على الضغطة (اختياري)
    try:
        bot.answer_callback_query(call.id, "✅ تم اختيار الطالب", show_alert=False)
    except:
        pass


# ═══════════════════════════════════════════════════════════════════════════════
# 3️⃣ دالة إرسال النتائج (النتيجة النهائية)
# ═══════════════════════════════════════════════════════════════════════════════

def send_student_result(user_id, student_data):
    """إرسال بيانات الطالب النهائية"""
    
    student_id = student_data['id']
    student_name = student_data['name']
    
    # بناء الرسالة
    message_text = f"""
📊 <b>بيانات الطالب</b>
━━━━━━━━━━━━━━━━━━━━
👤 <b>الاسم:</b> {student_name}
🆔 <b>رقم الجلوس:</b> {student_data.get('student_id', 'N/A')}
📚 <b>القسم:</b> {student_data.get('department', 'N/A')}

⭐ <b>المعدل العام:</b> {student_data.get('gpa', 'N/A')}
"""
    
    # إنشاء أزرار للخيارات
    keyboard = types.InlineKeyboardMarkup()
    
    keyboard.add(
        types.InlineKeyboardButton("📊 الإحصائيات", callback_data=f"stats_{student_id}"),
        types.InlineKeyboardButton("📈 الرسوم البيانية", callback_data=f"charts_{student_id}")
    )
    
    keyboard.add(
        types.InlineKeyboardButton("💡 نصائح ذكية", callback_data=f"tips_{student_id}"),
        types.InlineKeyboardButton("⚠️ تنبيهات", callback_data=f"alerts_{student_id}")
    )
    
    keyboard.add(
        types.InlineKeyboardButton("🔙 بحث جديد", callback_data="new_search")
    )
    
    # إرسال النتيجة
    bot.send_message(
        user_id,
        message_text,
        reply_markup=keyboard,
        parse_mode='HTML'
    )


# ═══════════════════════════════════════════════════════════════════════════════
# 4️⃣ نسخة محسّنة مع Caching و Validation
# ═══════════════════════════════════════════════════════════════════════════════

@bot.message_handler(commands=['search2'])  # نسخة محسّنة
def handle_search_improved(message):
    """البحث المحسّن مع معالجة أفضل"""
    user_id = message.from_user.id
    
    # 1. التحقق من المدخلات
    text = message.text.replace('/search2', '').strip()
    
    if not text:
        markup = types.ForceReply(selective=True)
        bot.send_message(
            user_id,
            "🔍 أدخل اسم الطالب الذي تبحث عنه:",
            reply_markup=markup
        )
        return
    
    if len(text) < 2:
        bot.send_message(user_id, "❌ الاسم قصير جداً (حرفين على الأقل)")
        return
    
    if len(text) > 50:
        bot.send_message(user_id, "❌ الاسم طويل جداً (50 حرف أقصى)")
        return
    
    # 2. البحث مع معالجة الأخطاء
    try:
        # تنظيف المدخل
        safe_text = InputValidator.sanitize_sql_input(text)
        
        # البحث
        response = supabase.table('students').select('*').ilike(
            'name', 
            f'%{safe_text}%'
        ).limit(15).execute()
        
        results = response.data or []
        
    except Exception as e:
        error_handler.handle("فشل البحث المحسّن", exception=e, user_id=user_id)
        bot.send_message(user_id, "❌ حدث خطأ في البحث، حاول لاحقاً")
        return
    
    # 3. لا نتائج
    if not results:
        bot.send_message(
            user_id,
            f"❌ لم يتم العثور على نتائج\n"
            f"البحث عن: <b>{text}</b>",
            parse_mode='HTML'
        )
        return
    
    # 4. عرض النتائج بشكل منظم
    keyboard = types.InlineKeyboardMarkup(row_width=1)
    
    for student in results:
        name = student.get('name', 'Unknown')
        sid = student.get('student_id', 'N/A')
        dept = student.get('department', '')
        
        # تنسيق الزر
        label = f"👤 {name}"
        if dept:
            label += f" ({dept})"
        
        keyboard.add(
            types.InlineKeyboardButton(
                label,
                callback_data=f"select_student_{student['id']}"
            )
        )
    
    # 5. رسالة البحث
    header = (
        f"🔍 <b>نتائج البحث</b>\n"
        f"━━━━━━━━━━━━━━━\n"
        f"البحث عن: <b>{text}</b>\n"
        f"عدد النتائج: <b>{len(results)}</b>\n\n"
        f"<i>اختر الطالب من القائمة:</i>"
    )
    
    search_msg = bot.send_message(
        user_id,
        header,
        reply_markup=keyboard,
        parse_mode='HTML'
    )
    
    # حفظ معرف الرسالة
    if not hasattr(bot, 'search_messages'):
        bot.search_messages = {}
    bot.search_messages[user_id] = search_msg.message_id
    
    db_logger.info(f"بحث عن: {text}", extra_data={'user_id': user_id, 'results': len(results)})


# ═══════════════════════════════════════════════════════════════════════════════
# 5️⃣ معالج البحث الجديد
# ═══════════════════════════════════════════════════════════════════════════════

@bot.callback_query_handler(func=lambda call: call.data == "new_search")
def handle_new_search(call):
    """البدء في بحث جديد"""
    user_id = call.from_user.id
    
    markup = types.ForceReply(selective=True)
    bot.send_message(
        user_id,
        "🔍 أدخل اسم الطالب الذي تبحث عنه:",
        reply_markup=markup
    )


# ═══════════════════════════════════════════════════════════════════════════════
# 6️⃣ النسخة المتقدمة - مع Pagination
# ═══════════════════════════════════════════════════════════════════════════════

@bot.message_handler(commands=['search3'])  # نسخة متقدمة مع Pagination
def handle_search_advanced(message):
    """البحث المتقدم مع Pagination للنتائج الكثيرة"""
    user_id = message.from_user.id
    
    text = message.text.replace('/search3', '').strip()
    
    if not text or len(text) < 2:
        bot.send_message(user_id, "❌ أدخل اسم الطالب (حرفين على الأقل)")
        return
    
    try:
        # البحث
        response = supabase.table('students').select('*').ilike(
            'name', 
            f'%{text}%'
        ).execute()
        
        results = response.data or []
        
    except Exception as e:
        error_handler.handle("فشل البحث المتقدم", exception=e, user_id=user_id)
        bot.send_message(user_id, "❌ حدث خطأ في البحث")
        return
    
    if not results:
        bot.send_message(user_id, f"❌ لم يتم العثور على نتائج عن '{text}'")
        return
    
    # إنشاء Pagination
    paginator = PaginatedResults(results, page_size=8)
    
    # الصفحة الأولى
    students, current_page, total_pages = paginator.get_page(1)
    
    # بناء الرسالة
    header = paginator.format_header(current_page, f"🔍 نتائج البحث: '{text}'")
    
    content = "\n".join([
        f"{i+1}. {s['name']} ({s.get('student_id', 'N/A')})"
        for i, s in enumerate(students)
    ])
    
    message_text = header + content
    
    # الأزرار
    keyboard = types.InlineKeyboardMarkup()
    
    # أزرار النتائج
    for student in students:
        keyboard.add(
            types.InlineKeyboardButton(
                f"✓ {student['name']}",
                callback_data=f"select_student_{student['id']}"
            )
        )
    
    # أزرار التنقل
    if total_pages > 1:
        nav_row = []
        if current_page > 1:
            nav_row.append(types.InlineKeyboardButton("⬅ السابق", callback_data=f"search_page_1_{text}"))
        if current_page < total_pages:
            nav_row.append(types.InlineKeyboardButton("التالي ➡", callback_data=f"search_page_2_{text}"))
        
        if nav_row:
            keyboard.row(*nav_row)
    
    # إرسال
    search_msg = bot.send_message(
        user_id,
        message_text,
        reply_markup=keyboard
    )
    
    if not hasattr(bot, 'search_messages'):
        bot.search_messages = {}
    bot.search_messages[user_id] = search_msg.message_id


# ═══════════════════════════════════════════════════════════════════════════════
# ملخص الاستخدام
# ═══════════════════════════════════════════════════════════════════════════════

"""
✅ ثلاث نسخ من البحث:

1️⃣ /search - البحث الأساسي
   - بسيط وسريع
   - عرض 15 نتيجة كحد أقصى
   - حذف القائمة وإرسال النتيجة

2️⃣ /search2 - البحث المحسّن
   - معالجة أفضل للمدخلات
   - رسائل أوضح
   - Logging للبحث

3️⃣ /search3 - البحث المتقدم
   - Pagination للنتائج الكثيرة
   - عرض 8-15 نتيجة في الصفحة
   - أزرار التنقل

الخاصية المشتركة:
✅ حذف قائمة الأزرار عند الضغط
✅ إرسال بيانات الطالب النهائية
✅ أزرار للخيارات الإضافية
✅ معالجة أخطاء شاملة
"""
