# 📋 مرجع الكود السريع - البحث التفاعلي

## 🎯 كيفية الاستخدام

نسخ الأكواد المطلوبة من هنا مباشرة واللصق في `final_bot_with_image.py`

---

## 1️⃣ الأوامر المسجلة

```python
# أضف في setup_bot_commands():
user_commands = [
    BotCommand("start", "🏠 البدء"),
    BotCommand("search", "🔍 البحث عن طالب"),  # ← هنا
    BotCommand("stats", "📊 إحصائيات"),
]
```

---

## 2️⃣ البحث الأساسي السريع

```python
@bot.message_handler(commands=['search'])
def search(msg):
    user_id = msg.from_user.id
    text = msg.text.replace('/search', '').strip()
    
    if not text:
        bot.send_message(user_id, "❌ أدخل اسم الطالب")
        return
    
    try:
        response = supabase.table('students').select('*').ilike('name', f'%{text}%').limit(15).execute()
        results = response.data or []
    except:
        bot.send_message(user_id, "❌ خطأ في البحث")
        return
    
    if not results:
        bot.send_message(user_id, "❌ لا توجد نتائج")
        return
    
    kb = types.InlineKeyboardMarkup()
    for s in results:
        kb.add(types.InlineKeyboardButton(
            text=f"{s['name']} ({s.get('student_id')})",
            callback_data=f"view_{s['id']}"
        ))
    
    msg_sent = bot.send_message(user_id, f"🔍 النتائج ({len(results)}):", reply_markup=kb)
    
    if not hasattr(bot, 'search_messages'):
        bot.search_messages = {}
    bot.search_messages[user_id] = msg_sent.message_id
```

---

## 3️⃣ معالج الاختيار والحذف

```python
@bot.callback_query_handler(func=lambda call: call.data.startswith('view_'))
def on_select(call):
    user_id = call.from_user.id
    msg_id = call.message.message_id
    student_id = int(call.data.replace('view_', ''))
    
    # حذف قائمة الأزرار
    try:
        bot.delete_message(user_id, msg_id)
    except:
        pass
    
    # جلب البيانات
    try:
        response = supabase.table('students').select('*').eq('id', student_id).execute()
        if not response.data:
            bot.send_message(user_id, "❌ لم يتم العثور على البيانات")
            return
        student = response.data[0]
    except:
        bot.send_message(user_id, "❌ خطأ في جلب البيانات")
        return
    
    # إرسال النتيجة
    text = f"""
📊 <b>بيانات الطالب</b>
━━━━━━━━━━━━━━━━━━━
👤 {student['name']}
🆔 {student.get('student_id')}
📚 {student.get('department')}
⭐ {student.get('gpa')}
"""
    
    kb = types.InlineKeyboardMarkup()
    kb.add(types.InlineKeyboardButton("🔍 بحث آخر", callback_data="search_new"))
    
    bot.send_message(user_id, text, reply_markup=kb, parse_mode='HTML')
    bot.answer_callback_query(call.id, "✅")


@bot.callback_query_handler(func=lambda call: call.data == "search_new")
def new_search(call):
    bot.send_message(call.from_user.id, "/search اسم الطالب")
```

---

## 4️⃣ البحث مع صور الملف الشخصي

```python
@bot.message_handler(commands=['search_with_picture'])
def search_with_picture(msg):
    user_id = msg.from_user.id
    text = msg.text.replace('/search_with_picture', '').strip()
    
    if not text:
        bot.send_message(user_id, "❌ أدخل اسم الطالب")
        return
    
    try:
        response = supabase.table('students').select('*').ilike('name', f'%{text}%').limit(15).execute()
        results = response.data or []
    except:
        bot.send_message(user_id, "❌ خطأ في البحث")
        return
    
    if not results:
        bot.send_message(user_id, "❌ لا توجد نتائج")
        return
    
    for student in results:
        name = student.get('name', 'Unknown')
        student_id = student.get('student_id', 'N/A')
        gpa = student.get('gpa', 'N/A')
        photo = student.get('photo_url')
        
        text = f"👤 {name}\n🆔 {student_id}\n⭐ {gpa}"
        
        kb = types.InlineKeyboardMarkup()
        kb.add(types.InlineKeyboardButton("📋 بيانات كاملة", callback_data=f"full_{student['id']}"))
        
        if photo:
            bot.send_photo(user_id, photo, caption=text, reply_markup=kb)
        else:
            bot.send_message(user_id, text, reply_markup=kb)
```

---

## 5️⃣ البحث مع الإحصائيات

```python
@bot.message_handler(commands=['search_stats'])
def search_stats(msg):
    user_id = msg.from_user.id
    text = msg.text.replace('/search_stats', '').strip()
    
    if not text:
        bot.send_message(user_id, "❌ أدخل اسم الطالب")
        return
    
    try:
        response = supabase.table('students').select('*').ilike('name', f'%{text}%').limit(15).execute()
        results = response.data or []
    except:
        bot.send_message(user_id, "❌ خطأ في البحث")
        return
    
    if not results:
        bot.send_message(user_id, "❌ لا توجد نتائج")
        return
    
    # حساب الإحصائيات
    avg_gpa = sum(float(s.get('gpa', 0)) for s in results) / len(results)
    
    kb = types.InlineKeyboardMarkup()
    for s in results:
        kb.add(types.InlineKeyboardButton(
            text=f"{s['name']} ⭐{s.get('gpa')}",
            callback_data=f"view_{s['id']}"
        ))
    
    text = f"""
🔍 <b>نتائج البحث</b>
━━━━━━━━━━━━━━━
📊 عدد النتائج: {len(results)}
📈 متوسط المعدل: {avg_gpa:.2f}
"""
    
    msg_sent = bot.send_message(user_id, text, reply_markup=kb, parse_mode='HTML')
    if not hasattr(bot, 'search_messages'):
        bot.search_messages = {}
    bot.search_messages[user_id] = msg_sent.message_id
```

---

## 6️⃣ البحث بـ Pagination (تقسيم النتائج)

```python
@bot.message_handler(commands=['search_paginated'])
def search_paginated(msg):
    user_id = msg.from_user.id
    text = msg.text.replace('/search_paginated', '').strip()
    
    if not text:
        bot.send_message(user_id, "❌ أدخل اسم الطالب")
        return
    
    try:
        response = supabase.table('students').select('*').ilike('name', f'%{text}%').execute()
        results = response.data or []
    except:
        bot.send_message(user_id, "❌ خطأ في البحث")
        return
    
    if not results:
        bot.send_message(user_id, "❌ لا توجد نتائج")
        return
    
    # تقسيم النتائج (8 في كل صفحة)
    page_size = 8
    total_pages = (len(results) + page_size - 1) // page_size
    
    def show_page(page=1):
        start = (page - 1) * page_size
        end = start + page_size
        page_results = results[start:end]
        
        kb = types.InlineKeyboardMarkup()
        for s in page_results:
            kb.add(types.InlineKeyboardButton(
                text=f"{s['name']}",
                callback_data=f"view_{s['id']}"
            ))
        
        # أزرار التصفح
        kb.row()
        if page > 1:
            kb.insert(types.InlineKeyboardButton("◀️ السابق", callback_data=f"page_{page-1}"))
        if page < total_pages:
            kb.insert(types.InlineKeyboardButton("التالي ▶️", callback_data=f"page_{page+1}"))
        
        kb_text = f"الصفحة {page}/{total_pages}"
        
        return kb, kb_text
    
    kb, kb_text = show_page(1)
    bot.send_message(user_id, f"🔍 النتائج\n{kb_text}", reply_markup=kb)
```

---

## 7️⃣ معالج الصفحات

```python
@bot.callback_query_handler(func=lambda call: call.data.startswith('page_'))
def handle_pagination(call):
    # يتطلب حفظ النتائج في متغير عام (يمكن التحسين لاحقاً)
    pass
```

---

## 8️⃣ البحث المتقدم مع التصنيف

```python
@bot.message_handler(commands=['search_advanced'])
def search_advanced(msg):
    user_id = msg.from_user.id
    text = msg.text.replace('/search_advanced', '').strip()
    
    if not text:
        bot.send_message(user_id, "❌ أدخل اسم الطالب")
        return
    
    try:
        response = supabase.table('students').select('*').ilike('name', f'%{text}%').execute()
        results = response.data or []
    except:
        bot.send_message(user_id, "❌ خطأ في البحث")
        return
    
    if not results:
        bot.send_message(user_id, "❌ لا توجد نتائج")
        return
    
    # تصنيف حسب المعدل
    excellent = [s for s in results if float(s.get('gpa', 0)) >= 3.5]
    good = [s for s in results if 3.0 <= float(s.get('gpa', 0)) < 3.5]
    average = [s for s in results if float(s.get('gpa', 0)) < 3.0]
    
    kb = types.InlineKeyboardMarkup()
    
    if excellent:
        kb.add(types.InlineKeyboardButton(f"⭐ ممتاز ({len(excellent)})", callback_data="filter_excellent"))
    if good:
        kb.add(types.InlineKeyboardButton(f"✅ جيد ({len(good)})", callback_data="filter_good"))
    if average:
        kb.add(types.InlineKeyboardButton(f"📋 عادي ({len(average)})", callback_data="filter_average"))
    
    kb.row(types.InlineKeyboardButton("🔍 الكل", callback_data="filter_all"))
    
    text = f"🔍 نتائج البحث: {len(results)}\n\nاختر التصنيف:"
    bot.send_message(user_id, text, reply_markup=kb)
```

---

## ✅ مرجعية سريعة

```
/search اسم          → بحث أساسي
/search_with_picture → بحث مع صور
/search_stats        → بحث مع إحصائيات
/search_paginated    → بحث مع تقسيم الصفحات
/search_advanced     → بحث متقدم
```

---

## 🔧 الدوال المساعدة

### تنسيق اسم الطالب
```python
def format_name(name, max_length=25):
    return name[:max_length] + "..." if len(name) > max_length else name
```

### تنسيق المعدل
```python
def format_gpa(gpa):
    try:
        return f"{float(gpa):.2f}/4.0"
    except:
        return "N/A"
```

### التحقق من الصلاحيات
```python
def can_search(user_id):
    # يمكن إضافة تحقق من الصلاحيات هنا
    return True
```

---

## 🚨 معالجة الأخطاء الشاملة

```python
try:
    response = supabase.table('students').select('*').ilike('name', f'%{search_text}%').execute()
    results = response.data or []
except Exception as e:
    logging.error(f"❌ خطأ البحث: {e}")
    bot.send_message(user_id, f"❌ حدث خطأ: {str(e)[:50]}")
    return
```

---

## 💾 حفظ البيانات المؤقتة

```python
if not hasattr(bot, 'temp_data'):
    bot.temp_data = {}

bot.temp_data[user_id] = {
    'search_results': results,
    'search_query': text,
    'timestamp': datetime.now()
}
```

---

## 🎯 الملخص

| الميزة | الأمر | الملف |
|-------|------|------|
| بحث أساسي | `/search` | `interactive_search.py` |
| مع الصور | `/search_with_picture` | هنا |
| مع الإحصائيات | `/search_stats` | هنا |
| مع الصفحات | `/search_paginated` | هنا |
| متقدم | `/search_advanced` | هنا |

**جرب الآن!** 🚀
